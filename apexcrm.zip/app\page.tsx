'use client';

import React, { useState, useMemo } from 'react';
import { 
  Building2, 
  ChevronRight, 
  MessageSquare, 
  Cpu, 
  Send, 
  Bot, 
  Globe, 
  Zap, 
  TrendingUp, 
  CheckCircle2, 
  Layers, 
  Code2, 
  Sliders, 
  PhoneCall, 
  Users, 
  ArrowRight,
  Shield,
  FileSpreadsheet,
  Settings,
  Terminal,
  Calculator,
  LayoutDashboard,
  Trophy,
  PieChart,
  Search,
  Trash2,
  Edit,
  Plus,
  X,
  FileText,
  ChevronDown,
  Clock,
  LogOut,
  MoreHorizontal
} from 'lucide-react';
import { motion } from 'motion/react';

// Modules structure
interface CRMModule {
  id: string;
  name: string;
  icon: React.ElementType;
  description: string;
  technicalMetric: string;
  conversionImpact: number; // absolute multiplier added to conversion rate
  inflowImpact: number; // percentage increase in incoming leads
  complexity: string;
}

// Available Apex CRM Modules for simulation
const modules: CRMModule[] = [
  {
    id: 'core_crm',
    name: 'Satış Odaklı CRM Çekirdeği',
    icon: Layers,
    description: 'Satış huninizi yöneten, geliri anlık takip eden ve işlem süresini kısaltan ana omurga.',
    technicalMetric: 'Süreç Basitleştirme (%40 Operasyonel Hız)',
    conversionImpact: 0.8, // +0.8%
    inflowImpact: 0,
    complexity: 'Temel Omurga',
  },
  {
    id: 'whatsapp_bulk',
    name: 'WhatsApp Sınırsız Toplu Mesaj & Otomasyon',
    icon: MessageSquare,
    description: 'Kısıtlama olmaksızın, kendi hatlarınız üzerinden rehberdeki veya aday listelerindeki binlerce kişiye güvenli sınırsız toplu WhatsApp mesajı gönderimi.',
    technicalMetric: 'WhatsApp Otomasyonu & Sınırsız Gönderim',
    conversionImpact: 2.5, // +2.5%
    inflowImpact: 20, // +20% traffic
    complexity: 'Sınırsız WhatsApp',
  },
  {
    id: 'sms_bulk',
    name: 'SMS Toplu Mesaj & Akıllı Kampanyalar',
    icon: Zap,
    description: 'Çoklu operatör entegrasyonu ile saniyeler içinde binlerce müşteriye SMS ile direkt pazarlama kampanyası ve akıllı süreç tetikleyicileri.',
    technicalMetric: 'Yüksek Hızlı Toplu SMS Dağıtımı',
    conversionImpact: 1.8, // +1.8%
    inflowImpact: 15,
    complexity: 'Hızlı Toplu SMS',
  },
  {
    id: 'high_perf_web',
    name: 'Kurumsal Satış Odaklı Dijital Varlık',
    icon: Globe,
    description: 'Maksimum veri dönüşümü için tasarlanmış, optimize edilmiş yüksek performanslı web altyapısı.',
    technicalMetric: 'Hafif Kod Yapısı (Lighthouse 98+ PageSpeed)',
    conversionImpact: 0.6, // +0.6%
    inflowImpact: 25, // +25% Traffic inflow boost
    complexity: 'Dönüşüm Odaklı Web',
  }
];

export default function ApexLandingPage() {
  // Simplified Revenue Growth State & Memo
  const [currentRevenue, setCurrentRevenue] = useState<number>(250000); // Ortalama Aylık Ciro (Default 250k TL)
  
  const calculatedGrowth = useMemo(() => {
    // A conservative, highly realistic 15% growth in efficiency and closed deals with ApexCRM
    const expectedRevenue = Math.round(currentRevenue * 1.15);
    const netCiroArtişi = expectedRevenue - currentRevenue;
    const extraHoursSaved = Math.round((currentRevenue / 50000) * 12 + 15); // Operasyonel saat kazancı
    const automatedRehabilitation = Math.round((currentRevenue / 100) + 1200); // Mesajlaşmayla canlanan pasif müşteri
    return {
      expectedRevenue,
      netCiroArtişi,
      extraHoursSaved: Math.min(160, Math.max(20, extraHoursSaved)),
      automatedRehabilitation,
    };
  }, [currentRevenue]);

  // Dynamic Contact Form State
  const [companyName, setCompanyName] = useState('');
  const [salesRepsCount, setSalesRepsCount] = useState('1-5');
  const [contactEmail, setContactEmail] = useState('');
  const [contactPhone, setContactPhone] = useState('');
  const [customComment, setCustomComment] = useState('');
  const [formError, setFormError] = useState('');
  const [formSubmitted, setFormSubmitted] = useState(false);

  // --- Real Interface Simulator States ---
  const [activeCrmTab, setActiveCrmTab] = useState('gosterge_paneli');
  const [customerSearchQuery, setCustomerSearchQuery] = useState('');
  const [customerFilterStatus, setCustomerFilterStatus] = useState('Tümü');
  
  const [customerListState, setCustomerListState] = useState([
    { id: 1, adSoyad: "DENEME", telefon: "90534212123", statu: "Aranmadı", sonNot: "DENEME", sonGuncelleme: "5 Haz 2026", temsilci: "denemeadmin" },
    { id: 2, adSoyad: "DENEME 2", telefon: "90555555555", statu: "Aranmadı", sonNot: "DENEME Y", sonGuncelleme: "5 Haz 2026", temsilci: "denemeadmin" },
    { id: 3, adSoyad: "DENEME 3", telefon: "90534444444", statu: "Takip", sonNot: "not olsun deneme olsun", sonGuncelleme: "5 Haz 2026", temsilci: "denemeadmin" },
    { id: 4, adSoyad: "DENEME2", telefon: "90533544444", statu: "Cevapsız", sonNot: "pot deneme", sonGuncelleme: "5 Haz 2026", temsilci: "denemesatis" }
  ]);

  // Messages Thread State
  const [activeChatThread, setActiveChatThread] = useState('denemesatis');
  const [newMessageText, setNewMessageText] = useState('');
  const [isCrmChatTyping, setIsCrmChatTyping] = useState(false);
  
  const [chatMessages, setChatMessages] = useState<Record<string, Array<{ sender: 'user' | 'rep'; text: string; time: string }>>>({
    denemesatis: [
      { sender: 'user', text: 'kolay gelsin', time: '13:57' },
      { sender: 'rep', text: 'teşekkürler', time: '13:57' }
    ],
    denemesatis2: [
      { sender: 'rep', text: 'deneme 2', time: '16/05' }
    ]
  });

  // Tasks State
  const [tasksList, setTasksList] = useState([
    { id: 1, isim: "HER GÜN 10 TAKİP", statu: "Takip", donem: "16 May — 16 Haz", kalanGun: "11 gün kaldı", ilerleme: 0, hedef: 200, not: `"Önemli" not eklenen benzersiz müşteri sayısı` },
    { id: 2, isim: "AYLIK5000NOT", statu: "Müşteri Arama", donem: "16 May — 16 Haz", kalanGun: "11 gün kaldı", ilerleme: 0, hedef: 5000, not: "Arama yapılan benzersiz müşteri sayısı" },
    { id: 3, isim: "250 ARAMA", statu: "Not Ekleme", donem: "16 May — 16 May", kalanGun: "20 gün geçti", ilerleme: 8, hedef: 200, not: "Eklenen toplam not sayısı", suresiGecti: true }
  ]);

  // Quotas State
  const [quotasState, setQuotasState] = useState([
    { id: 1, isim: "Hesap Açılışı", ilerleme: 0, hedef: 10 }
  ]);

  // Handler to add custom CRM customer
  const [newCrmCustName, setNewCrmCustName] = useState('');
  const [newCrmCustPhone, setNewCrmCustPhone] = useState('');
  const [newCrmCustNot, setNewCrmCustNot] = useState('');
  const [showAddCustModal, setShowAddCustModal] = useState(false);

  const handleAddCrmCustomer = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newCrmCustName) return;
    const newCust = {
      id: Date.now(),
      adSoyad: newCrmCustName,
      telefon: newCrmCustPhone || "905XXXXXXXX",
      statu: "Aranmadı",
      sonNot: newCrmCustNot || "Yeni eklendi",
      sonGuncelleme: "Bugün",
      temsilci: "denemeadmin"
    };
    setCustomerListState([newCust, ...customerListState]);
    setNewCrmCustName('');
    setNewCrmCustPhone('');
    setNewCrmCustNot('');
    setShowAddCustModal(false);
  };

  // Handler to send message in CRM chat
  const handleCrmSendMessage = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newMessageText.trim()) return;

    const text = newMessageText;
    const currentThread = activeChatThread;
    
    // Add user message
    const updatedUserMsgs: Array<{ sender: 'user' | 'rep'; text: string; time: string }> = [
      ...chatMessages[currentThread],
      { sender: 'user' as const, text, time: '13:58' }
    ];
    setChatMessages({
      ...chatMessages,
      [currentThread]: updatedUserMsgs
    });
    setNewMessageText('');

    // Simulate real response with a short delay
    setIsCrmChatTyping(true);
    setTimeout(() => {
      let responseText = "Harika! Teknik ekibimiz detaylar için en kısa zamanda birebir sizinle irtibata geçecekler 👍";
      if (currentThread === 'denemesatis2') {
        responseText = "Anlaşıldı yönetici bey, test araması ve not entegrasyonu tamamen sorunsuz çalışıyor.";
      }
      const responseMsg = { sender: 'rep' as const, text: responseText, time: '13:59' };
      setChatMessages(prev => ({
        ...prev,
        [currentThread]: [
          ...prev[currentThread],
          responseMsg
        ]
      }));
      setIsCrmChatTyping(false);
    }, 1200);
  };

  const handleContactSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!companyName || !contactEmail || !contactPhone) {
      setFormError('Lütfen tüm zorunlu iletişim alanlarını doldurunuz.');
      return;
    }
    setFormError('');
    setFormSubmitted(true);
  };

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 selection:bg-indigo-500/20 selection:text-indigo-200">
      
      {/* Upper Technical Status Bar - Styled professional */}
      <div className="bg-slate-950 text-slate-400 py-2.5 px-4 text-xs font-mono border-b border-slate-900/80">
        <div className="max-w-7xl mx-auto flex flex-col md:flex-row justify-between items-start md:items-center gap-2">
          <div className="flex items-center gap-2 text-slate-400">
            <span className="inline-block w-2 h-2 rounded-full bg-indigo-500"></span>
            <span>ApexCRM Üretim Hattı / Entegre Modüler Mimari</span>
          </div>
          <div className="flex items-center gap-4">
            <span className="text-indigo-400 font-bold">Destek: apexcrmdestek@gmail.com</span>
            <span className="hidden sm:inline border-l border-slate-800 h-3"></span>
            <span>Paket Yazılım Değil, Terzi Usulü Kodlama</span>
          </div>
        </div>
      </div>

      {/* Modern High-Contrast Navigation Header */}
      <header className="sticky top-0 z-50 bg-slate-950/80 backdrop-blur-md border-b border-slate-900/80">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-18 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-lg bg-indigo-600 flex items-center justify-center shadow-lg shadow-indigo-500/20">
              <span className="text-white font-mono font-bold text-lg tracking-wider">▲</span>
            </div>
            <div>
              <span className="text-xl font-bold tracking-tight text-white font-mono">Apex<span className="text-indigo-500">CRM</span></span>
              <p className="text-[10px] text-slate-500 tracking-widest uppercase font-mono leading-none mt-1">Sales-Oriented Engineering</p>
            </div>
          </div>

          <nav className="hidden md:flex items-center gap-8 text-sm font-medium text-slate-400">
            <a href="#neden-apex" className="hover:text-indigo-400 transition-colors">Neden ApexCRM?</a>
            <a href="#simulasyon" className="hover:text-indigo-400 transition-colors">Satış Simülatörü</a>
            <a href="#guclendirenler" className="hover:text-indigo-400 transition-colors">Güçlendirici Araçlar</a>
            <a href="#teknik-mimari" className="hover:text-indigo-400 transition-colors">Mimari Yaklaşım</a>
          </nav>

          <div className="flex items-center gap-3">
            <a 
              id="nav-consultation-btn"
              href="#istisare" 
              className="px-5 py-2.5 bg-indigo-600 text-white text-sm font-medium rounded-lg hover:bg-indigo-500 transition-all shadow-md shadow-indigo-500/10 hover:shadow-lg flex items-center gap-2"
            >
              <span>Mimari Analiz İsteyin</span>
              <ArrowRight className="w-4 h-4 text-indigo-300" />
            </a>
          </div>
        </div>
      </header>

      {/* Elegant Typographic Display HERO Section */}
      <section className="relative overflow-hidden pt-20 pb-24 md:pt-28 md:pb-32 border-b border-slate-900 bg-linear-to-b from-slate-950 to-slate-900/55">
        {/* Background Decorative Minimal Elements */}
        <div className="absolute inset-0 z-0 opacity-[0.03] pointer-events-none">
          <svg className="w-full h-full" xmlns="http://www.w3.org/2000/svg">
            <defs>
              <pattern id="grid-pattern" width="40" height="40" patternUnits="userSpaceOnUse">
                <path d="M 40 0 L 0 0 0 40" fill="none" stroke="currentColor" strokeWidth="1" />
              </pattern>
            </defs>
            <rect width="100%" height="100%" fill="url(#grid-pattern)" />
          </svg>
        </div>

        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 lg:gap-16 items-center">
            
            {/* Left Content Column */}
            <div className="lg:col-span-7 space-y-8">
              <div className="inline-flex items-center gap-2 px-3 py-1.5 rounded-full bg-indigo-500/10 border border-indigo-500/20 text-indigo-400 text-xs font-mono">
                <span className="w-2 h-2 rounded-full bg-indigo-500 animate-pulse"></span>
                <span>Yazılım Geliştirici & Kurumsal Çözüm Ortağı</span>
              </div>

              <h1 className="text-4xl sm:text-5xl lg:text-6xl font-extrabold tracking-tight text-white leading-[1.1]">
                Sadece Veri Saklamayan, <br className="hidden sm:inline" />
                <span className="text-indigo-500">Anlaşmaları Kapatan</span> <br />
                Bir Satış Makinesi.
              </h1>

              <p className="text-lg text-slate-400 font-sans leading-relaxed max-w-2xl">
                ApexCRM, işletmenizin satış hunisini hassas algoritmalarla yöneten, geliri anlık takip eden ve operasyonu hızlandıran ana merkezdir. Temsilcileri veri girişiyle boğmayan, süreçleri basitleştiren ve satış kapatma hızını artırmaya odaklanmış mühendislik harikası bir altyapı.
              </p>

              <div className="p-5 rounded-xl border border-slate-800 bg-slate-900/50 backdrop-blur-xs space-y-3">
                <div className="flex items-center gap-2">
                  <span className="p-1 rounded-md bg-indigo-500/20 text-indigo-400 text-xs font-bold font-mono">ÖZEL GELİŞTİRME</span>
                  <span className="text-xs text-slate-500 font-mono">•</span>
                  <span className="text-xs text-slate-300 font-medium font-sans">Kurumsal Yapınıza Özel</span>
                </div>
                <p className="text-sm text-slate-400 leading-relaxed font-sans">
                  Hazır, kısıtlayıcı paketlerimiz yoktur. İşletmenizin mevcut dinamiklerine veya istediğiniz özel fonksiyonel senaryolara göre CRM modüllerini sıfırdan uyarlıyor veya baştan inşa ediyoruz.
                </p>
              </div>

              <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-4 pt-2">
                <a 
                  id="hero-cta-primary"
                  href="#simulasyon" 
                  className="px-8 py-4 bg-indigo-600 hover:bg-indigo-500 text-white font-semibold rounded-xl transition-all text-center flex items-center justify-center gap-2 shadow-lg shadow-indigo-500/20 hover:shadow-xl"
                >
                  <Calculator className="w-5 h-5 text-indigo-300" />
                  <span>Satış Getiri Simülasyonu</span>
                </a>
                <a 
                  id="hero-cta-secondary"
                  href="#neden-apex" 
                  className="px-8 py-4 bg-slate-900 text-slate-300 font-medium rounded-xl hover:bg-slate-800 border border-slate-800 transition-all text-center flex items-center justify-center gap-2"
                >
                  <span>Teknik Detayları Keşfet</span>
                </a>
              </div>
            </div>

            {/* Right Interactive Mockup Column - Visual telemetry pipeline showing deal progression */}
            <div className="lg:col-span-5 relative">
              <div className="relative mx-auto max-w-md lg:max-w-none bg-slate-950 rounded-2xl border border-slate-800 p-6 shadow-2xl shadow-slate-950/40 font-mono text-xs text-slate-300">
                
                {/* Visual Terminal Bar */}
                <div className="flex justify-between items-center border-b border-slate-800 pb-4 mb-4">
                  <div className="flex gap-2">
                    <span className="w-3 h-3 rounded-full bg-red-500/80 block"></span>
                    <span className="w-3 h-3 rounded-full bg-amber-500/80 block"></span>
                    <span className="w-3 h-3 rounded-full bg-emerald-500/80 block"></span>
                  </div>
                  <span className="text-[10px] text-slate-500 uppercase font-mono tracking-wider">ApexCRM v4.8: Live Funnel Tracker</span>
                </div>

                {/* Simulated Pipeline stats */}
                <div className="space-y-4">
                  <div className="grid grid-cols-2 gap-3">
                    <div className="bg-slate-900 p-3 rounded border border-slate-800">
                      <p className="text-[10px] text-slate-500 uppercase mb-0.5">YAKALANAN ADAYLAR</p>
                      <p className="text-lg font-bold text-slate-100">1,200</p>
                      <span className="text-[9px] text-indigo-400 font-sans">Otomatik Senkronizasyon Akışı</span>
                    </div>
                    <div className="bg-slate-900/60 p-3 rounded border border-slate-800/80">
                      <p className="text-[10px] text-slate-500 uppercase mb-0.5">DÖNÜŞÜM ORANI</p>
                      <p className="text-lg font-bold text-indigo-400">%5.8</p>
                      <span className="text-[9px] text-slate-500 font-sans">ApexCRM Entegre Süreciyle</span>
                    </div>
                  </div>

                  {/* Operational Telemetry Metrics */}
                  <div className="bg-slate-900/60 p-4 rounded border border-slate-800/80 space-y-3">
                    <div className="flex justify-between items-center border-b border-slate-850 pb-2">
                      <span className="text-slate-400">Çoklu Numara İletişim Yönetimi</span>
                      <span className="text-indigo-400 font-bold">Merkezi Panel</span>
                    </div>
                    <div className="flex justify-between items-center border-b border-slate-850 pb-2">
                      <span className="text-slate-400">Birebir Süreç Analizi Çalışması</span>
                      <span className="text-indigo-400 font-bold">Özel Kodlama</span>
                    </div>
                    <div className="flex justify-between items-center">
                      <span className="text-slate-400">Süreç Bazlı Dinamik Planlayıcı</span>
                      <span className="text-indigo-400 font-bold">Kolay Görev Dağılımı</span>
                    </div>
                  </div>

                  {/* Sales Pipeline Funnel Progression visually mapped */}
                  <div className="bg-slate-900/40 p-3.5 rounded border border-slate-800/60 space-y-2">
                    <p className="text-[10px] text-slate-400 uppercase tracking-wider mb-2">Satış Hunisi Dağılım Hızı</p>
                    
                    {/* Stage 1 */}
                    <div className="space-y-1">
                      <div className="flex justify-between text-[10px] text-slate-400">
                        <span>1. Kalifikasyon Aşaması</span>
                        <span>%100</span>
                      </div>
                      <div className="w-full bg-slate-800 h-2 rounded-full overflow-hidden">
                        <div className="bg-slate-600 h-full w-[100%]"></div>
                      </div>
                    </div>

                    {/* Stage 2 */}
                    <div className="space-y-1">
                      <div className="flex justify-between text-[10px] text-slate-400">
                        <span>2. Teknik Değerlendirme & Teklif</span>
                        <span>%62</span>
                      </div>
                      <div className="w-full bg-slate-800 h-2 rounded-full overflow-hidden">
                        <div className="bg-indigo-600 h-full w-[62%]"></div>
                      </div>
                    </div>

                    {/* Stage 3 */}
                    <div className="space-y-1">
                      <div className="flex justify-between text-[10px] text-slate-400">
                        <span>3. Anlaşma Kapatma (Mutabakat)</span>
                        <span>%41</span>
                      </div>
                      <div className="w-full bg-slate-800 h-2 rounded-full overflow-hidden">
                        <div className="bg-indigo-400 h-full w-[41%]"></div>
                      </div>
                    </div>
                  </div>

                  {/* Custom Support Guarantee */}
                  <div className="text-[10px] text-slate-500 space-y-1.5 pt-1.5 font-sans">
                    <p>✓ Size özel dedike sunucu altyapısı kurulumu</p>
                    <p>✓ Uçtan uca güvenli veri izolasyon güvencesi</p>
                    <p>✓ Birebir kurumsal süreç analizi & gelişim desteği</p>
                  </div>

                </div>

                {/* Overlaid Floating Achievement Tag */}
                <div className="absolute -bottom-6 -left-6 bg-slate-900 text-slate-200 p-4 rounded-xl border border-slate-800 shadow-2xl shadow-indigo-500/5 max-w-[210px] font-sans backdrop-blur-md bg-opacity-95">
                  <div className="flex items-center gap-2 mb-1">
                    <div className="p-1 rounded bg-indigo-500/10 text-indigo-400">
                      <TrendingUp className="w-4 h-4" />
                    </div>
                    <span className="text-xs font-bold text-white tracking-tight">Net Sonuç</span>
                  </div>
                  <p className="text-[11px] text-slate-400 leading-snug">
                    Süreç takibi zorlamaz, temsilciyi yormaz; sadece sonuca odaklandırır.
                  </p>
                </div>

              </div>
            </div>

          </div>
        </div>
      </section>

      {/* CORE VALUE SECTION - Neden ApexCRM? */}
      <section id="neden-apex" className="py-24 border-b border-slate-900 bg-slate-950">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          
          <div className="text-center max-w-3xl mx-auto space-y-4 mb-20">
            <span className="text-xs font-mono font-bold uppercase tracking-widest text-indigo-400 px-3 py-1 bg-indigo-500/10 border border-indigo-500/20 rounded-full">
              SATIŞ ODAKLI FELSEFE
            </span>
            <h2 className="text-3xl sm:text-4xl font-extrabold tracking-tight text-white animate-fade-in">
              Sadece Veri Tutan Programlar Devrini Kapatıyoruz
            </h2>
            <p className="text-slate-400 font-sans leading-relaxed">
              Piyasadaki standart veritabanları temsilcilerinize sürekli kayıt girmeyi dayatır, işlerini zorlaştırır. ApexCRM ise anlaşmaları kapatmaya odaklanan bir satış makinesidir.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            
            {/* Value Postulate 1 */}
            <div className="p-8 rounded-2xl border border-slate-850 bg-slate-900/40 hover:bg-slate-900 hover:border-slate-850 transition-all duration-300 space-y-6 flex flex-col justify-between">
              <div className="space-y-4">
                <div className="w-12 h-12 rounded-xl bg-indigo-600 flex items-center justify-center text-white shadow-md shadow-indigo-500/20">
                  <Zap className="w-6 h-6" />
                </div>
                <h3 className="text-xl font-bold text-white">Sonuca Odaklı Satış Makinesi</h3>
                <p className="text-slate-400 text-sm leading-relaxed font-sans">
                  Gereksiz veri tarlaları ve form doldurma zorunlulukları yerine, doğrudan satış hunisindeki tıkanıklıkları gideren akıllı arayüz tasarımları. Temsilcileriniz vakitlerini sisteme rapor girmekle değil, müşterileriyle görüşerek geçirir.
                </p>
              </div>
              <div className="pt-4 border-t border-slate-800 flex items-center text-xs font-mono text-indigo-400 font-bold gap-1">
                <span>VERİM ODAKLI TASARIM</span>
                <ChevronRight className="w-3.5 h-3.5" />
              </div>
            </div>

            {/* Value Postulate 2 */}
            <div className="p-8 rounded-2xl border border-slate-850 bg-slate-900/40 hover:bg-slate-900 hover:border-slate-850 transition-all duration-300 space-y-6 flex flex-col justify-between">
              <div className="space-y-4">
                <div className="w-12 h-12 rounded-xl bg-indigo-600 flex items-center justify-center text-white shadow-md shadow-indigo-500/20">
                  <Sliders className="w-6 h-6" />
                </div>
                <h3 className="text-xl font-bold text-white">Özelleştirilebilir Modüler Yapı</h3>
                <p className="text-slate-400 text-sm leading-relaxed font-sans">
                  Kullanmadığınız, ekranları kalabalıklaştıran yüzlerce alan yerine, yalnızca satış ekiplerinizin ihtiyaçlarına göre uyarlanmış modülleri görünür kılarız. Sektörünüze özel süreç adımlarını sisteme %100 uyarlarız.
                </p>
              </div>
              <div className="pt-4 border-t border-slate-800 flex items-center text-xs font-mono text-indigo-400 font-bold gap-1">
                <span>%100 ESNEK YAPILANDIRMA</span>
                <ChevronRight className="w-3.5 h-3.5" />
              </div>
            </div>

            {/* Value Postulate 3 */}
            <div className="p-8 rounded-2xl border border-slate-850 bg-slate-900/40 hover:bg-slate-900 hover:border-slate-850 transition-all duration-300 space-y-6 flex flex-col justify-between">
              <div className="space-y-4">
                <div className="w-12 h-12 rounded-xl bg-indigo-600 flex items-center justify-center text-white shadow-md shadow-indigo-500/20">
                  <CheckCircle2 className="w-6 h-6" />
                </div>
                <h3 className="text-xl font-bold text-white">Kullanıcıyı Takibe Zorlamayan Akış</h3>
                <p className="text-slate-400 text-sm leading-relaxed font-sans">
                  Satış temsilcisini mikroyönetimle takip etmeye çalışarak bunaltmaz. Aksine, yapay işlem tıkanıklarını ortadan kaldırarak temsilcinin önündeki karmaşık adımları otomatik sonlandırır ve işini ciddi ölçüde basitleştirir.
                </p>
              </div>
              <div className="pt-4 border-t border-slate-800 flex items-center text-xs font-mono text-indigo-400 font-bold gap-1">
                <span>BASİTLEŞTİRİLMİŞ ERGONOMİ</span>
                <ChevronRight className="w-3.5 h-3.5" />
              </div>
            </div>

          </div>

        </div>
      </section>

      {/* INTERACTIVE SALES PERFORMANCE SIMULATOR (BASİTLEŞTİRİLMİŞ CİRO VE VERİMLİLİK HESAPLAYICI) */}
      <section id="simulasyon" className="py-24 border-b border-slate-900 bg-slate-950 text-slate-100">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          
          <div className="text-center max-w-3xl mx-auto space-y-4 mb-16">
            <span className="text-xs font-mono font-bold uppercase tracking-widest text-indigo-400 px-3 py-1 bg-indigo-500/10 border border-indigo-500/20 rounded-full">
              KOLAY CİRO VE VERİMLİLİK ANALİZİ
            </span>
            <h2 className="text-3xl sm:text-4xl font-extrabold tracking-tight text-white font-sans">
              İşletmenizin Potansiyelini Hesaplayın
            </h2>
            <p className="text-slate-400 font-sans leading-relaxed">
              Mevcut aylık cironuzu seçin; ApexCRM entegre akıllı iletişim algoritmaları, sınırsız toplu mesajlaşma ve operasyonel sadeleştirme gücünün getireceği rasyonel değerleri anında görün.
            </p>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-stretch">
            
            {/* Left Column - Slider Control */}
            <div className="lg:col-span-5 flex flex-col justify-between bg-slate-900/40 p-6 md:p-8 rounded-2xl border border-slate-800 space-y-8">
              <div className="space-y-6">
                <div>
                  <span className="text-[10px] text-slate-500 font-mono block uppercase">GİRİŞ DEĞERİ</span>
                  <h3 className="text-lg font-bold text-slate-200 mt-1 font-sans">Ortalama Aylık Cironuz</h3>
                  <p className="text-xs text-slate-400 mt-1.5 font-sans leading-relaxed">
                    İşletmenizin şu anki aylık tahmini toplam satış değerini girerek sistemin size kazandıracağı minimum katma değeri ölçeklendirin.
                  </p>
                </div>

                {/* Slider Input widget */}
                <div className="space-y-3 pt-2">
                  <div className="flex justify-between items-center bg-slate-950 p-4 rounded-xl border border-slate-850">
                    <span className="text-xs text-slate-400 font-mono">Tahmini Ciro:</span>
                    <span className="text-indigo-400 font-extrabold text-lg md:text-xl font-mono">
                      {currentRevenue.toLocaleString('tr-TR')} ₺
                    </span>
                  </div>
                  <input 
                    id="simulator-current-revenue-range"
                    type="range" 
                    min="50000" 
                    max="3000000" 
                    step="50000" 
                    value={currentRevenue}
                    onChange={(e) => setCurrentRevenue(Number(e.target.value))}
                    className="w-full accent-indigo-500 bg-slate-850 h-2 rounded-lg cursor-pointer"
                  />
                  <div className="flex justify-between text-[10px] text-slate-500 font-mono px-1">
                    <span>50K ₺</span>
                    <span>1.5M ₺</span>
                    <span>3M+ ₺</span>
                  </div>
                </div>
              </div>

              {/* Information disclaimer info inside parameters */}
              <div className="p-4 rounded-xl bg-slate-950/40 border border-slate-805 space-y-2">
                <div className="flex items-center gap-1.5 text-slate-300">
                  <span className="text-indigo-400 text-xs">ℹ</span>
                  <span className="text-[11px] font-bold text-white font-mono uppercase">ANALİZ KRİTERLERİ</span>
                </div>
                <p className="text-[11px] text-slate-500 leading-relaxed font-sans">
                  Hesaplama, temsilcilerin günde fazladan yapabileceği görüşme adetleri, sınırsız toplu reklam erişimleri ve takipsizlikten dolayı kaybedilmeyen sıcak satışların Türkiye pazarındaki rasyonel ortalamalarına dayanır.
                </p>
              </div>
            </div>

            {/* Right Column - Results Display Dashboard */}
            <div className="lg:col-span-7 bg-slate-900/60 p-6 md:p-8 rounded-2xl border border-slate-800 space-y-6 flex flex-col justify-between">
              
              <div className="space-y-6">
                <div className="flex justify-between items-center border-b border-slate-800 pb-4">
                  <div>
                    <span className="text-[10px] text-indigo-400 font-mono block tracking-widest uppercase">ApexCRM PROJEKSİYONU</span>
                    <span className="text-sm font-bold text-white font-sans mt-0.5">Öngörülen Aylık Büyüme Seviyesi</span>
                  </div>
                  <span className="px-3 py-1 rounded bg-emerald-500/10 border border-emerald-500/25 text-emerald-400 font-bold text-xs font-mono">
                    +%15 Gelir Artışı
                  </span>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  {/* Revenue Growth Outcome card */}
                  <div className="p-5 bg-slate-950/40 border border-slate-805 rounded-xl text-left space-y-2">
                    <span className="text-[10px] text-slate-400 block font-sans">ApexCRM Entegresiyle Projelendirilen Ciro:</span>
                    <span className="text-2xl font-black text-white font-mono block">
                      {calculatedGrowth.expectedRevenue.toLocaleString('tr-TR')} ₺ <span className="text-xs text-slate-500">/ ay</span>
                    </span>
                    <p className="text-xs text-emerald-400 font-bold leading-tight font-sans">
                      + {calculatedGrowth.netCiroArtişi.toLocaleString('tr-TR')} ₺ NET AYLIK KAZANÇ
                    </p>
                  </div>

                  {/* Sınırsız Toplu Kampanya Canlandırma card */}
                  <div className="p-5 bg-slate-950/40 border border-slate-805 rounded-xl text-left space-y-2">
                    <span className="text-[10px] text-slate-400 block font-sans">WhatsApp & SMS Toplu Mesaj Gücü:</span>
                    <span className="text-2xl font-black text-indigo-450 font-mono block">
                      {calculatedGrowth.automatedRehabilitation.toLocaleString('tr-TR')} <span className="text-xs text-slate-400">Pasif Kontak</span>
                    </span>
                    <p className="text-xs text-slate-400 leading-tight font-sans">
                      Toplu bildirimler ile huninize anında geri dönen sıcak adaylar.
                    </p>
                  </div>
                </div>

                {/* Saves / Efficiencies detailed row */}
                <div className="p-4 bg-indigo-950/15 border border-indigo-500/10 rounded-xl flex items-center gap-4">
                  <div className="w-10 h-10 rounded-lg bg-indigo-500/10 border border-indigo-500/20 text-indigo-400 flex items-center justify-center font-bold font-mono text-base shrink-0">
                    +{calculatedGrowth.extraHoursSaved}s
                  </div>
                  <div className="space-y-0.5">
                    <p className="text-xs font-bold text-slate-200">Kazanılan Ek Operasyonel Zaman (Temsilci Başı)</p>
                    <p className="text-[11px] text-slate-400 leading-relaxed font-sans">
                      Giriş yapılan verilerin sadeleşmesiyle, temsilcilerinize her ay ekstradan kazandırılan serbest satış görüşme saatidir.
                    </p>
                  </div>
                </div>
              </div>

              {/* Action Buttons Link footer of simulator */}
              <div className="flex flex-col sm:flex-row justify-between items-center gap-4 pt-4 border-t border-slate-850">
                <p className="text-[11px] text-slate-500 font-sans leading-normal text-center sm:text-left max-w-sm">
                  * Hazır kalıplarımız yoktur. Sistemimiz firmanıza özel kodlanır, kısıtlayıcı WhatsApp API ücretleri ödemeden sınırsız gönderim yaparsınız.
                </p>
                <a 
                  id="simulator-get-quote-btn"
                  href="#istisare" 
                  className="px-5 py-3 bg-indigo-600 hover:bg-indigo-500 text-white font-bold text-xs rounded-lg transition-all shadow-md shadow-indigo-500/10 flex items-center gap-1.5 shrink-0"
                >
                  <Cpu className="w-4 h-4 text-indigo-300" />
                  <span>Süreç Analizi ve Teklif İsteyin</span>
                </a>
              </div>

            </div>

          </div>

        </div>
      </section>

      {/* DETAILED BOOSTER TOOLS - Satış Performansını Artıran Araçlar */}
      <section id="guclendirenler" className="py-24 border-b border-slate-900 bg-slate-950 text-slate-100">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          
          <div className="text-center max-w-3xl mx-auto space-y-4 mb-20">
            <span className="text-xs font-mono font-bold uppercase tracking-widest text-indigo-400 px-3 py-1 bg-indigo-500/10 border border-indigo-500/20 rounded-full">
              CRM’İN GÜCÜ: ENTEGRE SİLAHLAR
            </span>
            <h2 className="text-3xl sm:text-4xl font-extrabold tracking-tight text-white font-sans">
              Satış Gücünü Katalize Eden Modüllerimiz
            </h2>
            <p className="text-slate-400 font-sans leading-relaxed">
              ApexCRM, çekirdek yapısının üzerine yerleştirilen, teknik açıdan üst seviye performans gösteren iletişim otomasyonları ve kurumsal altyapılarla donatılmıştır.
            </p>
          </div>

          <div className="space-y-16">
            
            {/* Tool 1: Çoklu Hat Birleştirme */}
            <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-center bg-slate-900/40 p-8 md:p-12 rounded-3xl border border-slate-800 hover:border-slate-700/80 transition-all duration-300 shadow-2xl shadow-indigo-500/2">
              <div className="lg:col-span-6 space-y-6">
                <div className="inline-flex items-center gap-2 px-3 py-1.5 rounded-lg bg-indigo-500/10 border border-indigo-500/20 text-indigo-400 text-xs font-mono font-bold">
                  <MessageSquare className="w-4 h-4" />
                  <span>İLETİŞİM HAVUZU MİMARİSİ</span>
                </div>

                <h3 className="text-2xl sm:text-3xl font-bold tracking-tight text-white font-sans">
                  Tüm İletişim Hatlarını Tek Merkezde Birleştirin
                </h3>

                <p className="text-slate-400 text-sm leading-relaxed font-sans">
                  İletişim kopukluklarını geride bırakın. Satış temsilcilerinizin veya destek uzmanlarınızın kullandığı tüm hatlar ya da iletişim kanalları tek panelde, tam senkronize olacak şekilde kurumunuza entegre edilir.
                </p>

                <div className="space-y-3 pt-2 font-sans">
                  <div className="flex items-start gap-2.5">
                    <CheckCircle2 className="w-4 h-4 text-indigo-500 mt-0.5 shrink-0" />
                    <div>
                      <p className="text-xs font-bold text-white">Kayıpsız Havuz Yönetimi</p>
                      <p className="text-[11px] text-slate-400 leading-relaxed">Müşterilerden gelen tüm mesajlar ve çağrı notları anında ilgili temsilcinin paneline düşer. Hiçbir sıcak aday veya bildirim cevapsız kalmaz.</p>
                    </div>
                  </div>
                  <div className="flex items-start gap-2.5">
                    <CheckCircle2 className="w-4 h-4 text-indigo-500 mt-0.5 shrink-0" />
                    <div>
                      <p className="text-xs font-bold text-white">Birebir Süreç Entegrasyonu</p>
                      <p className="text-[11px] text-slate-400 leading-relaxed">Biz hazır kısıtlı API satışları yapan bir yazılım distribütörü değiliz. Ekiplerinizle birebir çalışarak tam ihtiyaç duydukları ekranları kodluyoruz.</p>
                    </div>
                  </div>
                </div>
              </div>

              <div className="lg:col-span-6 bg-slate-950 p-6 rounded-2xl border border-slate-800 font-sans text-xs text-slate-300 space-y-4">
                <div className="flex justify-between items-center text-[10px] text-slate-500 border-b border-slate-800/80 pb-2 font-mono">
                  <span>HİZMET DETAYI: ÇOKLU NUMARA PANELİ</span>
                  <span className="text-indigo-400 font-bold">TAM ENTEGRASYON</span>
                </div>
                
                <div className="space-y-3">
                  <div className="p-3 rounded bg-slate-900/40 border border-slate-800">
                    <span className="font-bold text-white block mb-1">Ortak İletişim Ekranı</span>
                    <p className="text-slate-400 text-[11px] leading-relaxed">
                      Sorumlularınızın kullandığı tüm hatlar ya da iletişim kanalları tek panelde birleştirilir. Kayıp adımlar ve cevapsız kalan görüşmeler sıfırlanır.
                    </p>
                  </div>
                  <div className="p-3 rounded bg-slate-900/40 border border-slate-800">
                    <span className="font-bold text-white block mb-1">Birebir Analiz & Planlama</span>
                    <p className="text-slate-400 text-[11px] leading-relaxed">
                      Herhangi bir hazır kısıtlamalı sistem veya bot satışı yapmıyoruz. Ekiplerinizle birebir görüşerek onların günlük iş akışına en uygun yapıyı kodluyoruz.
                    </p>
                  </div>
                </div>

                <div className="bg-slate-900/40 text-slate-300 p-4 rounded-lg border border-slate-800 text-[11px] leading-relaxed">
                  <p className="text-indigo-400 font-bold mb-1">✓ Birebir Teknik Destek Hattı:</p>
                  <p className="text-slate-400">Yazılım ekibimizle doğrudan iletişim kurarsınız. Arada aracı firmalar veya standart destek formları olmadan en hızlı teknik çözüme ve desteğe anında ulaşırsınız.</p>
                </div>
              </div>
            </div>

            {/* Tool 2: Bireysel Görev ve Zaman Yönetimi */}
            <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-center bg-slate-900/40 p-8 md:p-12 rounded-3xl border border-slate-800 hover:border-slate-700/80 transition-all duration-300 shadow-2xl shadow-indigo-500/2">
              
              <div className="lg:col-span-6 lg:order-2 space-y-6">
                <div className="inline-flex items-center gap-2 px-3 py-1.5 rounded-lg bg-indigo-500/10 border border-indigo-500/20 text-indigo-400 text-xs font-mono font-bold">
                  <Bot className="w-4 h-4" />
                  <span>SÜREÇ VE PLANLAMA MİMARİSİ</span>
                </div>

                <h3 className="text-2xl sm:text-3xl font-bold tracking-tight text-white font-sans">
                  Sorumluluk Dağılımı ve Görev Kontrolü
                </h3>

                <p className="text-slate-400 text-sm leading-relaxed font-sans">
                  Satış ekibinizin koordinasyonu ve takibi hiç bu kadar koordine olmamıştı. Temsilcilerinizin yapacağı aramalar, müşteri geri dönüşleri ve randevular, takvimleri ile tam entegre çalışarak aksiyon bekleyen dinamik görev kartlarına dönüşür.
                </p>

                <div className="space-y-3 pt-2 font-sans">
                  <div className="flex items-start gap-2.5">
                    <CheckCircle2 className="w-4 h-4 text-indigo-500 mt-0.5 shrink-0" />
                    <div>
                      <p className="text-xs font-bold text-white">Anlık Görev Atama Akışı</p>
                      <p className="text-[11px] text-slate-400 leading-relaxed">Her yeni aday veya fırsat sistem tarafından otomatik olarak uygun yetkiliye tanımlanır, takibinde gecikme yaşanmasını engeller.</p>
                    </div>
                  </div>
                  <div className="flex items-start gap-2.5">
                    <CheckCircle2 className="w-4 h-4 text-indigo-500 mt-0.5 shrink-0" />
                    <div>
                      <p className="text-xs font-bold text-white">Birebir Süreç Optimizasyonu</p>
                      <p className="text-[11px] text-slate-400 leading-relaxed">Ekranları dolduran onlarca karmaşık metrik yerine, temsilcilerin sadece yapacağı işe ve görüşeceği müşteriye odaklanmasını sağlıyoruz.</p>
                    </div>
                  </div>
                </div>
              </div>

              <div className="lg:col-span-6 lg:order-1 bg-slate-950 p-6 rounded-2xl border border-slate-800 font-sans text-xs text-slate-300 space-y-4">
                <div className="flex justify-between items-center text-[10px] text-slate-500 border-b border-slate-800 pb-2 font-mono">
                  <span>PLANLAYICI: AKTİF GÖREV AKIŞI</span>
                  <span className="text-indigo-400 font-bold">GÖREVLERİM</span>
                </div>

                <div className="space-y-3">
                  <div className="bg-slate-900/50 p-3 rounded border border-slate-800/80 space-y-1">
                    <div className="flex justify-between items-center">
                      <span className="text-white font-bold text-[11px]">Sıcak Aday Geri Dönüşü</span>
                      <span className="text-indigo-400 text-[10px] font-bold font-mono">Bugün 15:30</span>
                    </div>
                    <p className="text-[11px] text-slate-400">Süreç Analiz talebi dolduran Apex Teknoloji firmasıyla teknik detay görüşmesi planlandı.</p>
                  </div>
                  <div className="bg-indigo-950/20 p-3 rounded border border-indigo-500/20 text-indigo-300 space-y-1 font-sans">
                    <div className="flex justify-between items-center">
                      <span className="font-bold text-indigo-400 text-[11px]">Teklif Hazırlama</span>
                      <span className="text-indigo-400 text-[10px] font-bold font-mono">Sona Yaklaştı</span>
                    </div>
                    <p className="text-[11px] text-slate-300">İşletmeye özel entegrasyon şeması tamamlandı, bütçe ve süre planı birebir iletişimle iletilecek.</p>
                  </div>
                </div>

                <div className="text-[10px] text-slate-500 pt-1 border-t border-slate-800 text-center font-sans">
                  Tamamen sadeleştirilmiş, temsilcinin zamanını çalmayan kurumsal görev havuzu.
                </div>
              </div>

            </div>

            {/* Tool 3: Core Corporate Digital Presence */}
            <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-center bg-slate-900/40 p-8 md:p-12 rounded-3xl border border-slate-800 hover:border-slate-700/80 transition-all duration-300 shadow-2xl shadow-indigo-500/2">
              <div className="lg:col-span-6 space-y-6">
                <div className="inline-flex items-center gap-2 px-3 py-1.5 rounded-lg bg-indigo-500/10 border border-indigo-500/20 text-indigo-400 text-xs font-mono font-bold">
                  <Globe className="w-4 h-4" />
                  <span>DÖNÜŞÜM ODAKLI WEBSİTESİ MÜHENDİSLİĞİ</span>
                </div>

                <h3 className="text-2xl sm:text-3xl font-bold tracking-tight text-white font-sans">
                  Kurumsal Satış Odaklı Dijital Varlık
                </h3>

                <p className="text-slate-400 text-sm leading-relaxed font-sans">
                  Sıradan, yavaş ve reklam kokan kurumsal siteler müşteri kaybettirir. Sizlere, tamamen <strong className="text-white font-sans font-bold">satış dönüşümüne (conversion) odaklanmış</strong>, hızlı, pürüzsüz ve teknik olarak kusursuz dökülmüş özel web siteleri tasarlıyoruz.
                </p>

                <div className="space-y-3 pt-2 font-sans">
                  <div className="flex items-start gap-2.5">
                    <CheckCircle2 className="w-4 h-4 text-indigo-500 mt-0.5 shrink-0" />
                    <div>
                      <p className="text-xs font-bold text-white">Gereksiz Süreçlerden Arındırılmış Yapı</p>
                      <p className="text-[11px] text-slate-400 leading-relaxed">Müşteriyi sayfalarca sıkmadan, doğrudan aradığı bilgiye ulaştıran ve hızlıca iletişim formunu tetiklermesini sağlayan sade, şık ve güçlü UI.</p>
                    </div>
                  </div>
                  <div className="flex items-start gap-2.5">
                    <CheckCircle2 className="w-4 h-4 text-indigo-500 mt-0.5 shrink-0" />
                    <div>
                      <p className="text-xs font-bold text-white">Gelişmiş API Huni Senkronizasyonu</p>
                      <p className="text-[11px] text-slate-400 leading-relaxed">Web sitenizden doldurulan her form veya atılan her adım, saliseler içerisinde doğrudan ApexCRM omurgasına hatasız düşer.</p>
                    </div>
                  </div>
                </div>
              </div>

              <div className="lg:col-span-6 space-y-4">
                <div className="border border-slate-800 bg-slate-950 p-6 rounded-2xl">
                  <div className="flex justify-between items-center text-[10px] text-slate-500 font-mono mb-4">
                     <span>WEB PERFORMANCE METRICS</span>
                     <span className="text-indigo-400 font-bold">LIGHTHOUSE REPORT</span>
                  </div>
                  
                  {/* Lighthouse Visual Ring and details */}
                  <div className="flex items-center justify-around gap-4 bg-slate-900 border border-slate-805 p-4 rounded-xl">
                    <div className="text-center">
                      <div className="w-16 h-16 rounded-full border-4 border-indigo-500 flex items-center justify-center font-bold text-lg text-indigo-400 font-mono bg-indigo-500/5">
                        99
                      </div>
                      <span className="text-[10px] text-slate-400 block mt-2 font-mono">Performans</span>
                    </div>
                    <div className="text-center">
                      <div className="w-16 h-16 rounded-full border-4 border-indigo-500 flex items-center justify-center font-bold text-lg text-indigo-400 font-mono bg-indigo-500/5">
                        100
                      </div>
                      <span className="text-[10px] text-slate-400 block mt-2 font-mono">Erişilebilirlik</span>
                    </div>
                    <div className="text-center">
                      <div className="w-16 h-16 rounded-full border-4 border-indigo-500 flex items-center justify-center font-bold text-lg text-indigo-400 font-mono bg-indigo-500/5">
                        98
                      </div>
                      <span className="text-[10px] text-slate-400 block mt-2 font-mono">En İyi Uygulama</span>
                    </div>
                  </div>

                  <p className="text-[11px] text-slate-400 text-center font-sans mt-3 leading-relaxed">
                    Statik sunucu taraflı site oluşturma (SSG) ve kenar sunucu (Edge) hızlandırma teknolojileri ile sıfır gecikmeli kullanıcı akışı.
                  </p>
                </div>
              </div>

            </div>

          </div>

        </div>
      </section>

      {/* INTERACTIVE CRM DEMO SECTION - CANLI ARAYÜZ KEŞFİ */}
      <section id="canli-panel" className="py-24 border-b border-slate-900 bg-slate-950 text-slate-100 relative">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          
          <div className="text-center max-w-3xl mx-auto space-y-4 mb-16">
            <span className="text-xs font-mono font-bold uppercase tracking-widest text-indigo-400 px-3 py-1 bg-indigo-500/10 border border-indigo-500/20 rounded-full">
              SİSTEMİN KALBİ: BİREBİR EKRANLARIMIZ
            </span>
            <h2 className="text-3xl sm:text-4xl font-extrabold tracking-tight text-white font-sans">
              ApexCRM Canlı Arayüzünü İnceleyin
            </h2>
            <p className="text-slate-400 font-sans leading-relaxed">
              Dahili CRM sistemimizin ne kadar sade, hızlı ve doğrudan sonuca odaklanan bir tasarıma sahip olduğunu canlı demomuz üzerinden tecrübe edin. Aşağıdaki menülerden geçiş yapabilir, örnek veri akışını yönetebilirsiniz.
            </p>
          </div>

          {/* Interactive Desktop Browser Container */}
          <div className="bg-slate-900/60 rounded-3xl border border-slate-800 shadow-2xl overflow-hidden backdrop-blur-sm">
            
            {/* Browser Header Controls */}
            <div className="bg-slate-950 px-5 py-4 border-b border-slate-850 flex items-center justify-between">
              <div className="flex items-center gap-2">
                <div className="w-3 h-3 rounded-full bg-red-500/80"></div>
                <div className="w-3 h-3 rounded-full bg-yellow-500/80"></div>
                <div className="w-3 h-3 rounded-full bg-green-500/80"></div>
              </div>
              <div className="bg-slate-900 border border-slate-800 rounded-lg px-4 py-1.5 text-xs text-slate-400 font-mono w-full max-w-[380px] text-center truncate">
                https://panel.apexcrm.com/{activeCrmTab.replace('_', '-')}
              </div>
              <div className="flex items-center gap-1.5 text-slate-500">
                <span className="text-[10px] bg-slate-900 border border-slate-850 px-2 py-0.5 rounded text-indigo-400 font-mono font-bold">DEMO MODU</span>
              </div>
            </div>

            {/* Main Application Outer Flex */}
            <div className="grid grid-cols-1 lg:grid-cols-12 min-h-[640px]">
              
              {/* LEFT SIDEBAR - Matches Screenshot Layout */}
              <div className="lg:col-span-3 bg-[#0d1326] border-r border-[#151c36] p-5 flex flex-col justify-between text-slate-300 font-sans">
                <div className="space-y-6">
                  {/* Brand Header */}
                  <div className="flex items-center gap-3 border-b border-indigo-950/40 pb-4">
                    <div className="w-9 h-9 rounded-lg bg-indigo-600 flex items-center justify-center font-bold text-white shadow-md shadow-indigo-500/10">
                      A
                    </div>
                    <div>
                      <span className="font-extrabold tracking-wider text-sm block font-sans text-white">ApexCRM</span>
                      <span className="text-[10px] text-slate-500 block leading-none font-mono">v3.8 Production</span>
                    </div>
                  </div>

                  {/* Sidebar Menu Items */}
                  <div className="space-y-1">
                    {[
                      { id: 'gosterge_paneli', key: 'gosterge_paneli', label: 'Gösterge Paneli', icon: LayoutDashboard },
                      { id: 'musteriler', key: 'musteriler', label: 'Müşteriler', icon: Users },
                      { id: 'mesajlar', key: 'mesajlar', label: 'Mesajlar', icon: MessageSquare, badge: 2 },
                      { id: 'gorevler', key: 'gorevler', label: 'Görevler', icon: CheckCircle2, badge: 'Aktif' },
                      { id: 'kotalar', key: 'kotalar', label: 'Kotalar', icon: Trophy },
                      { id: 'kaynak_analizi', key: 'kaynak_analizi', label: 'Kaynak Analizi', icon: PieChart },
                    ].map((item) => {
                      const IconComp = item.icon;
                      const isActive = activeCrmTab === item.id;
                      return (
                        <button
                          key={item.id}
                          onClick={() => setActiveCrmTab(item.id)}
                          className={`w-full flex items-center justify-between px-3.5 py-3 rounded-lg text-xs font-semibold tracking-wide transition-all ${
                            isActive 
                              ? 'bg-indigo-600 text-white shadow-md shadow-indigo-600/10' 
                              : 'hover:bg-slate-900/60 text-slate-400 hover:text-slate-200'
                          }`}
                        >
                          <div className="flex items-center gap-3">
                            <IconComp className={`w-4 h-4 shrink-0 ${isActive ? 'text-white' : 'text-slate-400'}`} />
                            <span>{item.label}</span>
                          </div>
                          {item.badge && (
                            <span className={`text-[9px] px-1.5 py-0.5 rounded-full font-bold ${isActive ? 'bg-white text-indigo-600' : 'bg-indigo-500/15 text-indigo-400'}`}>
                              {item.badge}
                            </span>
                          )}
                        </button>
                      );
                    })}

                    {/* Passive/Non-interactive tabs for visual fidelity matching screenshot */}
                    <div className="pt-2 border-t border-slate-900/50 space-y-1 opacity-70">
                      {[
                        { label: 'KYC Yönetimi', icon: Shield },
                        { label: 'Toplu Yükleme', icon: FileSpreadsheet },
                        { label: 'Toplu Yönetim', icon: Users },
                        { label: 'Ayarlar', icon: Settings }
                      ].map((pItem, idx) => {
                        const PIcon = pItem.icon;
                        return (
                          <div
                            key={idx}
                            className="w-full flex items-center gap-3 px-3.5 py-2.5 text-xs font-semibold text-slate-550 select-none cursor-not-allowed"
                          >
                            <PIcon className="w-4 h-4 text-slate-600" />
                            <span>{pItem.label}</span>
                          </div>
                        );
                      })}
                    </div>
                  </div>
                </div>

                {/* Profile Widget Bottom */}
                <div className="border-t border-[#1a233d] pt-4 mt-6">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-xs font-bold font-sans text-white">denemeadmin</p>
                      <p className="text-[10px] text-slate-500 font-mono">Yönetici</p>
                    </div>
                    <button 
                      onClick={() => alert('Demo modundan çıkılamaz. İletişim formu üzerinden gerçek sisteme erişim talep edebilirsiniz.')}
                      className="p-1.5 rounded hover:bg-red-500/10 text-slate-500 hover:text-red-400 transition-colors"
                      title="Çıkış Yap"
                    >
                      <LogOut className="w-4 h-4" />
                    </button>
                  </div>
                </div>
              </div>

              {/* RIGHT CONTENT WORKSPACE - Slate-100 light theme matching original screens */}
              <div className="lg:col-span-9 bg-[#f4f7fa] p-6 lg:p-8 text-slate-800 flex flex-col justify-between">
                
                {/* DYNAMIC SCREEN PREVIEW ROUTER */}
                <div className="space-y-6">

                  {/* SCREEN 1: GÖSTERGE PANELI (DASHBOARD) */}
                  {activeCrmTab === 'gosterge_paneli' && (
                    <div className="space-y-6 animate-fade-in">
                      <div className="flex justify-between items-center pb-2 border-b border-slate-200">
                        <div>
                          <h3 className="text-xl font-extrabold text-slate-900 tracking-tight">Merhaba, denemeadmin 👋</h3>
                          <p className="text-xs text-slate-500 mt-0.5 font-sans">5 Haziran 2026 Cuma / Performans özeti ve anlık akış</p>
                        </div>
                      </div>

                      {/* Six Stats Grid */}
                      <div className="grid grid-cols-2 md:grid-cols-6 gap-4">
                        {[
                          { title: 'Toplam Müşteri', value: customerListState.length, color: 'text-indigo-600 border-indigo-100 bg-white' },
                          { title: 'Aktif Yatırımcı', value: 0, color: 'text-emerald-600 border-emerald-100 bg-white' },
                          { title: 'Takip / İlgili', value: customerListState.filter(c => c.statu === 'Takip').length, color: 'text-amber-600 border-amber-100 bg-white' },
                          { title: 'Bekleyen KYC', value: 0, color: 'text-rose-600 border-rose-100 bg-white' },
                          { title: 'Hesap Talebi', value: 3, color: 'text-blue-600 border-blue-100 bg-white' },
                          { title: 'Atanmamış', value: customerListState.filter(c => c.statu === 'Aranmadı').length, color: 'text-slate-500 border-slate-100 bg-white' },
                        ].map((stat, sidx) => (
                          <div key={sidx} className={`p-4 rounded-xl border shadow-sm ${stat.color}`}>
                            <span className="text-[10px] text-slate-400 font-sans block truncate font-medium">{stat.title}</span>
                            <span className="text-xl font-extrabold font-mono block mt-1.5">{stat.value}</span>
                          </div>
                        ))}
                      </div>

                      {/* Analytics visual graph details */}
                      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
                        
                        {/* Column 7: Weekly line graph indicator */}
                        <div className="lg:col-span-8 bg-white p-5 rounded-2xl border border-slate-200 shadow-xs space-y-4">
                          <div className="flex justify-between items-center">
                            <span className="text-xs font-bold text-slate-800 font-sans">Son 7 Gün — Yeni Müşteri</span>
                            <span className="text-[10px] bg-indigo-50 text-indigo-600 px-2 py-0.5 rounded font-mono font-bold">Günlük Akış</span>
                          </div>
                          
                          {/* Visual representation of empty chart */}
                          <div className="h-44 flex items-end justify-between px-6 pt-4 border-b border-l border-slate-150 relative">
                            <div className="absolute inset-x-0 top-1/4 border-t border-dashed border-slate-100 w-full"></div>
                            <div className="absolute inset-x-0 top-2/4 border-t border-dashed border-slate-100 w-full"></div>
                            <div className="absolute inset-x-0 top-3/4 border-t border-dashed border-slate-100 w-full"></div>
                            
                            {/* Days labels - match clean graph in screenshot with 0 data points */}
                            {['30 Cmt', '31 Paz', '1 Pzt', '2 Sal', '3 Çar', '4 Per', '5 Cum'].map((day, dIdx) => (
                              <div key={dIdx} className="flex-1 flex flex-col items-center justify-end h-full relative z-10">
                                <div className="absolute bottom-0 w-2 h-2 rounded-full bg-indigo-500 border-2 border-white mb-[-4px]"></div>
                                <span className="text-[9px] text-slate-400 font-sans mt-2 translate-y-6 absolute whitespace-nowrap">{day}</span>
                              </div>
                            ))}
                            {/* Visual SVG Line */}
                            <svg className="absolute inset-0 h-full w-full pointer-events-none" preserveAspectRatio="none">
                              <polyline
                                fill="none"
                                stroke="#6366f1"
                                strokeWidth="2.5"
                                points="30,132 100,132 170,132 240,132 310,132 380,132 450,132"
                              />
                            </svg>
                          </div>
                        </div>

                        {/* Column 4: Statü Dağılımı Pie display */}
                        <div className="lg:col-span-4 bg-white p-5 rounded-2xl border border-slate-200 shadow-xs space-y-4">
                          <span className="text-xs font-bold text-slate-800 font-sans block">Statü Dağılımı</span>
                          
                          {/* Simulated pie chart visual */}
                          <div className="flex justify-center items-center py-2">
                            <div className="relative w-24 h-24 rounded-full border-8 border-slate-200 flex items-center justify-center">
                              {/* Colored arcs simulated via simple SVG */}
                              <svg className="absolute -inset-2 w-28 h-28 transform -rotate-90">
                                <circle cx="56" cy="56" r="44" fill="transparent" stroke="#4f46e5" strokeWidth="12" strokeDasharray="180 276" />
                                <circle cx="56" cy="56" r="44" fill="transparent" stroke="#0ea5e9" strokeWidth="12" strokeDasharray="50 276" strokeDashoffset="-180" />
                                <circle cx="56" cy="56" r="44" fill="transparent" stroke="#f59e0b" strokeWidth="12" strokeDasharray="30 276" strokeDashoffset="-230" />
                              </svg>
                              <span className="text-xs font-bold text-slate-800 font-mono">10</span>
                            </div>
                          </div>

                          <div className="space-y-1.5 text-[10px] font-sans">
                            <div className="flex justify-between items-center text-slate-600">
                              <span className="flex items-center gap-1.5"><span className="w-2.5 h-2.5 rounded-full bg-indigo-600 block"></span> Aranmadı</span>
                              <span className="font-bold">6 (%60)</span>
                            </div>
                            <div className="flex justify-between items-center text-slate-600">
                              <span className="flex items-center gap-1.5"><span className="w-2.5 h-2.5 rounded-full bg-sky-500 block"></span> Takip</span>
                              <span className="font-bold">2 (%20)</span>
                            </div>
                            <div className="flex justify-between items-center text-slate-600">
                              <span className="flex items-center gap-1.5"><span className="w-2.5 h-2.5 rounded-full bg-amber-500 block"></span> Cevapsız</span>
                              <span className="font-bold">1 (%10)</span>
                            </div>
                          </div>
                        </div>

                      </div>
                    </div>
                  )}


                  {/* SCREEN 2: MÜŞTERİ LİSTESİ (CUSTOMERS) */}
                  {activeCrmTab === 'musteriler' && (
                    <div className="space-y-5 animate-fade-in">
                      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 pb-2 border-b border-slate-200">
                        <div>
                          <h3 className="text-xl font-extrabold text-slate-900 tracking-tight">Müşteriler</h3>
                          <p className="text-xs text-slate-500 mt-0.5 font-sans">Müşteri listesi ve detaylı süreç yönetimi</p>
                        </div>
                        <button 
                          onClick={() => setShowAddCustModal(true)}
                          className="px-4 py-2 bg-indigo-600 hover:bg-indigo-500 text-white font-bold text-xs rounded-lg shadow-sm transition-all flex items-center gap-1.5"
                        >
                          <Plus className="w-4 h-4" />
                          <span>Müşteri Ekle</span>
                        </button>
                      </div>

                      {/* Search and Filters panel */}
                      <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-sm space-y-4">
                        <div className="relative">
                          <Search className="w-4 h-4 absolute left-3 top-3 text-slate-400" />
                          <input 
                            type="text" 
                            placeholder="Müşteri adı, telefon veya not ara..." 
                            value={customerSearchQuery}
                            onChange={(e) => setCustomerSearchQuery(e.target.value)}
                            className="bg-slate-50 border border-slate-200 rounded-lg pl-9 pr-4 py-2 text-xs w-full text-slate-800 placeholder-slate-400 focus:outline-hidden focus:border-indigo-500"
                          />
                        </div>

                        {/* Status filters selection row */}
                        <div className="flex flex-wrap gap-1.5 items-center">
                          <span className="text-[10px] text-slate-400 font-bold font-sans mr-1">Statü:</span>
                          {['Tümü', 'Aranmadı', 'Cevapsız', 'Takip'].map((status) => (
                            <button
                              key={status}
                              onClick={() => setCustomerFilterStatus(status)}
                              className={`px-2.5 py-1 rounded text-[10px] font-sans font-bold transition-colors ${
                                customerFilterStatus === status 
                                  ? 'bg-indigo-600 text-white' 
                                  : 'bg-slate-100 hover:bg-slate-200 text-slate-600'
                              }`}
                            >
                              {status}
                            </button>
                          ))}
                        </div>
                      </div>

                      {/* Modal to add custom simulated customer */}
                      {showAddCustModal && (
                        <div className="bg-white p-5 rounded-xl border-2 border-indigo-500 shadow-xl space-y-4">
                          <div className="flex justify-between items-center border-b border-slate-100 pb-2">
                            <h4 className="text-xs font-bold text-slate-900">Müşteri Detaylarını Girin</h4>
                            <button onClick={() => setShowAddCustModal(false)} className="text-slate-400 hover:text-slate-600"><X className="w-4 h-4" /></button>
                          </div>
                          <form onSubmit={handleAddCrmCustomer} className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                            <input 
                              type="text" 
                              required 
                              placeholder="Ad Soyad" 
                              value={newCrmCustName}
                              onChange={(e) => setNewCrmCustName(e.target.value)}
                              className="bg-slate-50 border border-slate-200 rounded px-2.5 py-1.5 text-xs text-slate-800 focus:outline-hidden focus:border-indigo-500"
                            />
                            <input 
                              type="text" 
                              placeholder="Telefon (Örn: 90532...)" 
                              value={newCrmCustPhone}
                              onChange={(e) => setNewCrmCustPhone(e.target.value)}
                              className="bg-slate-50 border border-slate-200 rounded px-2.5 py-1.5 text-xs text-slate-800 focus:outline-hidden focus:border-indigo-500"
                            />
                            <input 
                              type="text" 
                              placeholder="Son Not" 
                              value={newCrmCustNot}
                              onChange={(e) => setNewCrmCustNot(e.target.value)}
                              className="bg-slate-50 border border-slate-200 rounded px-2.5 py-1.5 text-xs text-slate-800 focus:outline-hidden focus:border-indigo-500"
                            />
                            <button type="submit" className="sm:col-span-3 py-1.5 bg-indigo-600 text-white font-bold text-xs rounded hover:bg-indigo-500 transition-colors">Kaydet</button>
                          </form>
                        </div>
                      )}

                      {/* Customers list grid */}
                      <div className="bg-white rounded-xl border border-slate-200 shadow-sm overflow-hidden">
                        <table className="w-full text-left border-collapse font-sans text-xs">
                          <thead>
                            <tr className="bg-slate-50 border-b border-slate-200 text-[10px] text-slate-400 font-bold uppercase">
                              <th className="p-3">Adı Soyadı</th>
                              <th className="p-3">Telefon</th>
                              <th className="p-3">Statü</th>
                              <th className="p-3">Son Not</th>
                              <th className="p-3">Temsilci</th>
                              <th className="p-3 text-right">İşlemler</th>
                            </tr>
                          </thead>
                          <tbody>
                            {/* Filtering logic applied */}
                            {customerListState.filter(c => {
                              const matchesSearch = c.adSoyad.toLowerCase().includes(customerSearchQuery.toLowerCase()) || 
                                                    c.telefon.includes(customerSearchQuery) || 
                                                    c.sonNot.toLowerCase().includes(customerSearchQuery.toLowerCase());
                              const matchesStatus = customerFilterStatus === 'Tümü' || c.statu === customerFilterStatus;
                              return matchesSearch && matchesStatus;
                            }).length === 0 ? (
                              <tr>
                                <td colSpan={6} className="p-6 text-center text-slate-400 font-sans italic">Kayıt bulunamadı. Aşağıdan filtreyi sıfırlayabilir veya sağ üstten yeni ekleyebilirsiniz.</td>
                              </tr>
                            ) : (
                              customerListState.filter(c => {
                                const matchesSearch = c.adSoyad.toLowerCase().includes(customerSearchQuery.toLowerCase()) || 
                                                      c.telefon.includes(customerSearchQuery) || 
                                                      c.sonNot.toLowerCase().includes(customerSearchQuery.toLowerCase());
                                const matchesStatus = customerFilterStatus === 'Tümü' || c.statu === customerFilterStatus;
                                return matchesSearch && matchesStatus;
                              }).map((cust) => (
                                <tr key={cust.id} className="border-b border-slate-100 hover:bg-slate-50/50">
                                  <td className="p-3 font-semibold text-slate-900">{cust.adSoyad}</td>
                                  <td className="p-3 font-mono font-medium text-slate-600">{cust.telefon}</td>
                                  <td className="p-3">
                                    <span className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                                      cust.statu === 'Aranmadı' ? 'bg-slate-100 text-slate-600' :
                                      cust.statu === 'Takip' ? 'bg-amber-50 text-amber-600' :
                                      cust.statu === 'Cevapsız' ? 'bg-rose-50 text-rose-600' :
                                      'bg-emerald-50 text-emerald-600'
                                    }`}>
                                      {cust.statu}
                                    </span>
                                  </td>
                                  <td className="p-3 text-slate-500 max-w-[200px] truncate leading-relaxed" title={cust.sonNot}>{cust.sonNot}</td>
                                  <td className="p-3 font-mono text-[10px] text-slate-500">{cust.temsilci}</td>
                                  <td className="p-3 text-right space-x-1 whitespace-nowrap">
                                    <button 
                                      onClick={() => {
                                        // Simple toggle state integration
                                        const updated = customerListState.map(c => {
                                          if (c.id === cust.id) {
                                            const statusCycles = ['Aranmadı', 'Takip', 'Cevapsız'];
                                            const nextIdx = (statusCycles.indexOf(c.statu) + 1) % statusCycles.length;
                                            return { ...c, statu: statusCycles[nextIdx] };
                                          }
                                          return c;
                                        });
                                        setCustomerListState(updated);
                                      }}
                                      className="px-2 py-1 border border-slate-200 hover:border-indigo-300 text-[10px] rounded hover:text-indigo-600 bg-white transition-all font-semibold"
                                      title="Statü Değiştir"
                                    >
                                      Süreç
                                    </button>
                                    <button 
                                      onClick={() => {
                                        setCustomerListState(customerListState.filter(c => c.id !== cust.id));
                                      }}
                                      className="p-1 hover:text-rose-600 text-slate-400"
                                      title="Örneği Sil"
                                    >
                                      <Trash2 className="w-3.5 h-3.5" />
                                    </button>
                                  </td>
                                </tr>
                              ))
                            )}
                          </tbody>
                        </table>
                      </div>
                    </div>
                  )}


                  {/* SCREEN 3: MESAJLAŞMA (CHAT ROOM) */}
                  {activeCrmTab === 'mesajlar' && (
                    <div className="space-y-4 animate-fade-in">
                      <div>
                        <h3 className="text-xl font-extrabold text-slate-900 tracking-tight">Merkezi Mesajlaşma</h3>
                        <p className="text-xs text-slate-500 mt-0.5 font-sans">Müşteri temsilci havuzuna entegre Whatsapp / Telegram yazışma ekranı</p>
                      </div>

                      {/* Split pane */}
                      <div className="grid grid-cols-1 md:grid-cols-12 border border-slate-200 bg-white rounded-2xl overflow-hidden shadow-sm h-[420px]">
                        
                        {/* Thread thread selection left pane */}
                        <div className="md:col-span-4 border-r border-slate-100 bg-slate-50/50 p-4 space-y-4 h-full flex flex-col justify-between">
                          <div className="space-y-3">
                            <span className="text-[9px] text-slate-400 font-mono font-bold uppercase block tracking-wider">Aktif Temsilci Görüşmeleri</span>
                            
                            <div className="space-y-1.5">
                              {[
                                { id: 'denemesatis', label: 'denemesatis', role: 'Satış Temsilcisi', last: 'teşekkürler', date: '5 Haz 2026', unread: true },
                                { id: 'denemesatis2', label: 'denemesatis2', role: 'Yönetici', last: 'deneme 2', date: '16 May' }
                              ].map((t) => (
                                <button
                                  key={t.id}
                                  onClick={() => setActiveChatThread(t.id)}
                                  className={`w-full text-left p-3 rounded-lg border transition-all flex items-start gap-2.5 ${
                                    activeChatThread === t.id 
                                      ? 'bg-indigo-600/5 border-indigo-200 text-slate-800 font-bold' 
                                      : 'bg-white border-slate-150 hover:bg-slate-50 text-slate-600'
                                  }`}
                                >
                                  <div className="w-7 h-7 rounded-full bg-slate-200 flex items-center justify-center font-bold text-xs uppercase font-sans text-slate-500">
                                    {t.label.charAt(0)}
                                  </div>
                                  <div className="flex-1 min-w-0">
                                    <div className="flex justify-between items-center text-[11px]">
                                      <span className="font-sans font-bold text-slate-800">{t.label}</span>
                                      <span className="text-[9px] text-slate-400">{t.date}</span>
                                    </div>
                                    <p className="text-[10px] text-slate-500 truncate mt-0.5 font-mono">{t.last}</p>
                                  </div>
                                </button>
                              ))}
                            </div>
                          </div>
                        </div>

                        {/* Thread message pane right */}
                        <div className="md:col-span-8 flex flex-col justify-between h-full bg-white">
                          
                          {/* Top Chat title */}
                          <div className="p-3.5 border-b border-slate-100 flex items-center justify-between bg-slate-50/30">
                            <div className="flex items-center gap-2">
                              <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-pulse"></span>
                              <span className="text-xs font-bold text-slate-850">{activeChatThread} ile Görüşme</span>
                            </div>
                            <span className="text-[10px] text-slate-400 font-mono">BİRLEŞİK İLETİŞİM</span>
                          </div>

                          {/* Message box area */}
                          <div className="flex-1 p-4 overflow-y-auto space-y-3.5 min-h-[220px]">
                            {chatMessages[activeChatThread]?.map((msg, midx) => (
                              <div 
                                key={midx} 
                                className={`flex ${msg.sender === 'user' ? 'justify-end' : 'justify-start'}`}
                              >
                                <div className={`max-w-[85%] rounded-2xl px-4 py-2.5 text-xs leading-relaxed ${
                                  msg.sender === 'user' 
                                    ? 'bg-indigo-600 text-white rounded-br-none' 
                                    : 'bg-slate-150 text-slate-850 rounded-bl-none'
                                }`}>
                                  <p>{msg.text}</p>
                                  <span className={`text-[8px] font-mono block text-right mt-1.5 ${
                                    msg.sender === 'user' ? 'text-indigo-200' : 'text-slate-400'
                                  }`}>
                                    {msg.time}
                                  </span>
                                </div>
                              </div>
                            ))}

                            {/* Typing feedback display */}
                            {isCrmChatTyping && (
                              <div className="flex justify-start">
                                <div className="bg-slate-100 text-slate-500 rounded-2xl px-3.5 py-2 text-[10px] font-sans flex items-center gap-1">
                                  <span className="w-1.5 h-1.5 bg-slate-400 rounded-full animate-bounce"></span>
                                  <span className="w-1.5 h-1.5 bg-slate-400 rounded-full animate-bounce delay-100"></span>
                                  <span className="w-1.5 h-1.5 bg-slate-400 rounded-full animate-bounce delay-200"></span>
                                  <span className="ml-1.5 italic font-medium">Cevap yazılıyor...</span>
                                </div>
                              </div>
                            )}
                          </div>

                          {/* Input element controls */}
                          <form onSubmit={handleCrmSendMessage} className="p-3 border-t border-slate-100 flex items-center gap-2">
                            <input 
                              type="text" 
                              placeholder="Simüle edilmiş mesajınızı girip Enter tuşuna basın..." 
                              value={newMessageText}
                              onChange={(e) => setNewMessageText(e.target.value)}
                              className="bg-slate-50 border border-slate-200 rounded-lg px-3 py-2 text-xs flex-1 text-slate-800 placeholder-slate-400 focus:outline-hidden focus:border-indigo-500 focus:ring-1 focus:ring-indigo-500"
                            />
                            <button
                              type="submit"
                              className="p-2 bg-indigo-600 hover:bg-indigo-500 text-white rounded-lg transition-colors flex items-center justify-center shrink-0"
                            >
                              <Send className="w-3.5 h-3.5" />
                            </button>
                          </form>

                        </div>

                      </div>
                    </div>
                  )}


                  {/* SCREEN 4: GÖREVLER (TASKS LIST) */}
                  {activeCrmTab === 'gorevler' && (
                    <div className="space-y-5 animate-fade-in">
                      <div>
                        <h3 className="text-xl font-extrabold text-slate-900 tracking-tight">Görevler</h3>
                        <p className="text-xs text-slate-500 mt-0.5 font-sans">Bireysel, toplu veya ekip hedefleri atayın.</p>
                      </div>

                      {/* Stat summary bar */}
                      <div className="grid grid-cols-2 md:grid-cols-4 gap-4 bg-white p-4 rounded-xl border border-slate-200 shadow-sm">
                        {[
                          { title: 'Aktif Görev', value: '3', border: 'border-indigo-100 text-indigo-600' },
                          { title: 'Tamamlanan', value: '0', border: 'border-emerald-100 text-emerald-600' },
                          { title: 'Hedefe Ulaşan', value: '0', border: 'border-sky-100 text-sky-600' },
                          { title: 'Süresi Geçen', value: '1', border: 'border-rose-100 text-rose-600' }
                        ].map((tsk, tIndex) => (
                          <div key={tIndex} className="p-3 rounded-lg bg-slate-50/50 border text-center">
                            <span className="text-[10px] text-slate-400 font-sans block font-semibold">{tsk.title}</span>
                            <span className={`text-lg font-extrabold font-mono mt-0.5 block ${tsk.border.split(' ')[1]}`}>{tsk.value}</span>
                          </div>
                        ))}
                      </div>

                      {/* Filter badges list */}
                      <div className="flex gap-2">
                        {['Aktif 3', 'Tamamlanan 0', 'İptal 1', 'Tümü 4'].map((bLabel, bidx) => (
                          <span 
                            key={bidx} 
                            className={`px-2.5 py-1 text-[10px] rounded font-bold font-sans ${
                              bidx === 0 ? 'bg-indigo-600 text-white' : 'bg-slate-200 text-slate-600'
                            }`}
                          >
                            {bLabel}
                          </span>
                        ))}
                      </div>

                      {/* Tasks display cards layout */}
                      <div className="space-y-3.5">
                        {tasksList.map((task) => (
                          <div 
                            key={task.id} 
                            className={`p-5 rounded-xl bg-white border shadow-xs flex flex-col md:flex-row justify-between items-start md:items-center gap-4 transition-all duration-200 hover:border-slate-300 ${
                              task.suresiGecti ? 'border-l-4 border-l-rose-500 border-slate-200' : 'border-slate-200'
                            }`}
                          >
                            <div className="space-y-2 flex-1 min-w-0">
                              <div className="flex items-center gap-2">
                                <span className="w-1.5 h-1.5 rounded-full bg-indigo-500"></span>
                                <h4 className="text-xs font-bold text-slate-900 truncate">{task.isim}</h4>
                                <span className={`px-2 py-0.5 text-[8px] font-bold rounded uppercase ${
                                  task.suresiGecti ? 'bg-rose-50 text-rose-500' : 'bg-indigo-50 text-indigo-500'
                                }`}>
                                  {task.statu}
                                </span>
                              </div>
                              <p className="text-[10px] text-slate-400 font-sans leading-relaxed">{task.not}</p>
                              <div className="flex items-center gap-4 text-[9px] text-slate-500 font-medium font-sans pt-1">
                                <span className="flex items-center gap-1"><Clock className="w-3.5 h-3.5 text-slate-400" /> {task.donem}</span>
                                <span className="font-bold text-slate-500">{task.kalanGun}</span>
                              </div>
                            </div>

                            {/* Progress bar and controls LHS */}
                            <div className="w-full md:w-52 space-y-2 flex flex-col items-end shrink-0">
                              <div className="w-full flex justify-between text-[10px] font-semibold font-mono text-slate-500">
                                <span>{task.ilerleme} / {task.hedef}</span>
                                <span>{Math.round((task.ilerleme / task.hedef) * 100)}%</span>
                              </div>
                              <div className="w-full bg-slate-100 h-1.5 rounded-full overflow-hidden">
                                <div className="bg-indigo-600 h-full rounded-full" style={{ width: `${(task.ilerleme / task.hedef) * 100}%` }}></div>
                              </div>
                              <button 
                                onClick={() => {
                                  setTasksList(tasksList.map(t => {
                                    if (t.id === task.id) {
                                      const nextProg = Math.min(t.hedef, t.ilerleme + 10);
                                      return { ...t, ilerleme: nextProg };
                                    }
                                    return t;
                                  }));
                                }}
                                className="text-[10px] border border-slate-250 hover:border-indigo-400 text-slate-600 hover:text-indigo-600 font-bold px-2 py-0.5 rounded bg-slate-50 transition-colors font-sans self-end"
                              >
                                İlerleme Ekle
                              </button>
                            </div>
                          </div>
                        ))}
                      </div>

                    </div>
                  )}


                  {/* SCREEN 5: SATIŞ KOTALARI (QUOTAS) */}
                  {activeCrmTab === 'kotalar' && (
                    <div className="space-y-5 animate-fade-in">
                      <div className="pb-2 border-b border-slate-200">
                        <h3 className="text-xl font-extrabold text-slate-900 tracking-tight">Satış Kotaları</h3>
                        <p className="text-xs text-slate-500 mt-0.5 font-sans">Satış temsilcilerine dönemlik hedef atayın ve performansı izleyin.</p>
                      </div>

                      {/* Multi metrics summaries cards layout */}
                      <div className="grid grid-cols-3 gap-6">
                        {[
                          { title: 'Toplam Hedef', value: '10' },
                          { title: 'Gerçekleşen', value: '0' },
                          { title: 'Hedefe Ulaşan', value: '0' }
                        ].map((stat, sIdx) => (
                          <div key={sIdx} className="bg-white p-5 rounded-2xl border border-slate-200 shadow-xs text-center space-y-1">
                            <span className="text-[10px] text-slate-400 font-bold block">{stat.title}</span>
                            <span className="text-xl font-extrabold font-mono text-slate-900 block mt-1">{stat.value}</span>
                          </div>
                        ))}
                      </div>

                      {/* Rep distribution detail card layout */}
                      <div className="bg-white rounded-xl border border-slate-200 shadow-sm overflow-hidden p-5 space-y-4">
                        <div className="flex justify-between items-center pb-2 border-b border-slate-100">
                          <div className="flex items-center gap-2">
                            <span className="w-6 h-6 rounded-full bg-slate-100 flex items-center justify-center font-bold text-[10px] text-slate-500 uppercase font-sans">D</span>
                            <span className="text-xs font-bold text-slate-850">denemeadmin <span className="font-normal text-slate-400">(1 kota)</span></span>
                          </div>
                          <span className="text-[10px] font-mono font-bold text-slate-500">0% (0 / 10)</span>
                        </div>

                        {/* List items representation */}
                        <div className="space-y-4">
                          {quotasState.map((q) => (
                            <div key={q.id} className="space-y-1.5 font-sans text-xs">
                              <div className="flex justify-between items-center text-slate-600">
                                <span className="font-semibold">{q.isim}</span>
                                <span className="font-semibold text-slate-800">{q.ilerleme} / {q.hedef} (%{Math.round((q.ilerleme / q.hedef) * 100)})</span>
                              </div>
                              <div className="w-full bg-slate-100 h-2 rounded-full overflow-hidden">
                                <div className="bg-indigo-600 h-full rounded-full" style={{ width: `${(q.ilerleme / q.hedef) * 100}%` }}></div>
                              </div>
                              <div className="flex justify-end gap-1.5 pt-1">
                                <button
                                  onClick={() => {
                                    setQuotasState(quotasState.map(qi => qi.id === q.id ? { ...qi, ilerleme: Math.min(qi.hedef, qi.ilerleme + 1) } : qi));
                                  }}
                                  className="text-[10px] border border-slate-200 hover:border-indigo-400 hover:text-indigo-600 px-2 py-0.5 rounded transition-colors bg-white font-semibold flex items-center gap-1"
                                >
                                  <span>+ Hedef Sayımı</span>
                                </button>
                              </div>
                            </div>
                          ))}
                        </div>
                      </div>

                    </div>
                  )}


                  {/* SCREEN 6: KAYNAK ANALIZI (LEAKS REPORT) */}
                  {activeCrmTab === 'kaynak_analizi' && (
                    <div className="space-y-5 animate-fade-in">
                      <div className="pb-2 border-b border-slate-200">
                        <h3 className="text-xl font-extrabold text-slate-900 tracking-tight">Kaynak Analizi</h3>
                        <p className="text-xs text-slate-500 mt-0.5 font-sans">Veri kaynaklarına göre detaylı müşteri analizi</p>
                      </div>

                      {/* General Summary Card metrics block */}
                      <div className="bg-white rounded-xl border border-slate-200 p-5 shadow-sm space-y-4">
                        <span className="text-xs font-bold text-slate-800 font-sans block border-b border-slate-100 pb-2">📈 Genel Özet</span>
                        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 pt-1">
                          {[
                            { title: 'Toplam Müşteri', value: '10' },
                            { title: 'Toplam Kaynak', value: '1' },
                            { title: 'Atanmış', value: '4', text: 'text-emerald-600' },
                            { title: 'Atanmamış', value: '6', text: 'text-amber-600' }
                          ].map((sm, sidx) => (
                            <div key={sidx} className="bg-slate-50/50 border border-slate-200 p-3 rounded-lg text-center space-y-1">
                              <span className="text-[10px] text-slate-400 block font-semibold">{sm.title}</span>
                              <span className={`text-lg font-extrabold font-mono mt-0.5 block ${sm.text || 'text-slate-800'}`}>{sm.value}</span>
                            </div>
                          ))}
                        </div>
                      </div>

                      {/* Dropdown chooser */}
                      <div className="space-y-1.5">
                        <span className="text-[10px] text-slate-400 uppercase tracking-widest font-mono font-bold block">Kaynak Seç (Detaylı Analiz)</span>
                        <select className="bg-white border border-slate-200 rounded-lg p-2.5 text-xs text-slate-800 font-sans w-full focus:outline-hidden">
                          <option>Tüm Kaynaklar</option>
                        </select>
                      </div>

                      {/* Source Lists Row matching 'efsane' card */}
                      <div className="space-y-3.5">
                        <span className="text-[10px] text-slate-400 font-mono font-bold uppercase block tracking-wider pt-2">Tüm Kaynaklar Özeti</span>

                        <div className="bg-white p-5 rounded-xl border border-slate-200 shadow-sm space-y-4">
                          <div className="flex justify-between items-center pb-2 border-b border-slate-100">
                            <span className="text-xs font-bold text-slate-800 font-sans">efsane</span>
                            <div className="flex gap-1.5">
                              <span className="text-[10px] bg-indigo-50 border border-indigo-100 text-indigo-600 font-semibold px-2 py-0.5 rounded">10 müşteri</span>
                              <span className="text-[10px] bg-slate-100 border border-slate-200 text-slate-600 font-semibold px-20 py-0.5 rounded hidden sm:inline">Detaylı Analiz</span>
                            </div>
                          </div>

                          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                            
                            {/* Total summary box */}
                            <div className="p-3 bg-slate-50 rounded-lg border border-slate-100 space-y-1 text-center">
                              <span className="text-[10px] text-slate-400 font-bold block">Toplam</span>
                              <span className="text-sm font-extrabold font-mono text-slate-800 block">10</span>
                            </div>

                            {/* Assigned box */}
                            <div className="p-3 bg-emerald-50 rounded-lg border border-emerald-100 space-y-1 text-center">
                              <span className="text-[10px] text-emerald-600 font-bold block">Atanmış</span>
                              <span className="text-sm font-extrabold font-mono text-emerald-600 block">4</span>
                              <span className="text-[9px] text-emerald-500 font-mono font-bold block leading-none pt-0.5">40.0%</span>
                            </div>

                            {/* Unassigned box */}
                            <div className="p-3 bg-amber-50 rounded-lg border border-amber-100 space-y-1 text-center">
                              <span className="text-[10px] text-amber-600 font-bold block">Atanmamış</span>
                              <span className="text-sm font-extrabold font-mono text-amber-600 block">6</span>
                              <span className="text-[9px] text-amber-500 font-mono font-bold block leading-none pt-0.5">60.0%</span>
                            </div>

                          </div>
                        </div>
                      </div>

                    </div>
                  )}

                </div>

                {/* SHARED VALUE INJECT DETAILS FOOTER */}
                <div className="p-4 bg-white border border-slate-200 rounded-xl mt-6">
                  <p className="text-[11px] text-slate-500 leading-relaxed font-sans text-center">
                    📢 <strong>Birebir Entegrasyon Analizi Gerekçesi:</strong> Bu ekran tasarımları, firmanızın gerçek operasyonel ihtiyaçlarına, sektörünüze ve ekiplerinizin alışkanlıklarına göre <strong>%100 terzi usulü</strong> esnetilip baştan kodlanır.
                  </p>
                </div>

              </div>

            </div>

          </div>

        </div>
      </section>
      <section id="teknik-mimari" className="py-24 border-b border-slate-900 bg-slate-950 text-slate-100 relative">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-16 items-center">
            
            {/* Left Content column */}
            <div className="lg:col-span-6 space-y-6">
              <span className="text-xs font-mono font-bold uppercase tracking-widest text-indigo-400 px-3 py-1 bg-indigo-500/10 border border-indigo-500/20 rounded-full">
                BİZ HAZIR PAKET SATAN BİR FİRMA DEĞİLİZ
              </span>
              <h2 className="text-3xl sm:text-4xl font-extrabold tracking-tight text-white leading-tight font-sans">
                Mühendislik Odaklı Mimari Yaklaşım
              </h2>
              <p className="text-slate-400 text-sm leading-relaxed font-sans">
                Geleneksel hazır CRM yazılımları, işletmenizi kendi kalıplarına sokmaya zorlar. Biz ise işletmenizin dinamiklerini derinlemesine inceleyen bir yazılım geliştirici ve kurumsal çözüm ortağıyız. 
              </p>
              
              <div className="space-y-4 font-sans text-sm">
                <div className="p-4 rounded-lg bg-slate-900/40 border border-slate-800">
                  <span className="text-indigo-450 font-bold block mb-1">Mevcut Altyapıya Sıfırdan Entegrasyon</span>
                  <p className="text-slate-400 text-xs leading-relaxed">
                    Eğer halihazırda kullandığınız özel ERP, fatura, veri ambarı veya lojistik sistemleriniz varsa; CRM&apos;i bunlarla tam uyumlu çalışacak şekilde baştan uyarlıyor veya entegre ediyoruz.
                  </p>
                </div>
                
                <div className="p-4 rounded-lg bg-slate-900/40 border border-slate-800">
                  <span className="text-indigo-450 font-bold block mb-1">Yeni Modüller Ekleyerek Dinamik Büyüme</span>
                  <p className="text-slate-400 text-xs leading-relaxed">
                    Şirketiniz geliştikçe yeni satış süreçlerine, ekiplerine veya kontrol panellerine ihtiyaç duyabilirsiniz. Kapsamlı modül geliştirme kütüphanemiz sayesinde, CRM sistemine gelecekte de kesintisiz fonksiyonlar ekliyoruz.
                  </p>
                </div>
              </div>
            </div>

            {/* Right Schematic Visual Component */}
            <div className="lg:col-span-6 relative bg-slate-900/25 p-6 md:p-8 rounded-2xl border border-slate-800 space-y-6 font-mono text-xs">
              <span className="text-slate-500 uppercase text-[10px] tracking-wider block">ApexCRM Kurumsal Entegrasyon Şeması</span>
              
              <div className="space-y-4">
                {/* Integration Node 1 */}
                <div className="flex items-center gap-4 bg-slate-900/50 p-3 rounded border border-slate-800/80">
                  <div className="w-8 h-8 rounded bg-slate-950 flex items-center justify-center text-slate-400 font-bold text-xs shrink-0 border border-slate-800">1</div>
                  <div className="text-[11px]">
                    <span className="text-white font-bold block">İşletme Mevcut Süreç Analizi</span>
                    <span className="text-slate-500 font-sans">Satış ekiplerinizin fiziki alışkanlıkları ve engelleri tespit edilir.</span>
                  </div>
                </div>

                {/* Arrow */}
                <div className="h-6 w-0.5 bg-dashed border-l border-indigo-500/40 ml-7"></div>

                {/* Integration Node 2 */}
                <div className="flex items-center gap-4 bg-slate-900/50 p-3 rounded border border-slate-800/80">
                  <div className="w-8 h-8 rounded bg-indigo-500/10 text-indigo-400 border border-indigo-500/30 flex items-center justify-center font-bold text-xs shrink-0">2</div>
                  <div className="text-[11px]">
                    <span className="text-white font-bold block">Bespoke (Terzi Usulü) Kod Geliştirme</span>
                    <span className="text-slate-500 font-sans">İhtiyaç duyulmayan tüm alanlar temizlenerek, sadece sonuca odaklı modüller dökülür.</span>
                  </div>
                </div>

                {/* Arrow */}
                <div className="h-6 w-0.5 bg-dashed border-l border-indigo-500/40 ml-7"></div>

                {/* Integration Node 3 */}
                <div className="flex items-center gap-4 bg-slate-900/50 p-3 rounded border border-slate-800/80">
                  <div className="w-8 h-8 rounded bg-slate-950 flex items-center justify-center text-slate-400 font-bold text-xs shrink-0 border border-slate-800">3</div>
                  <div className="text-[11px]">
                    <span className="text-white font-bold block">Pürüzsüz Entegrasyon & Devreye Alma</span>
                    <span className="text-slate-500 font-sans">WhatsApp hatları, botlar ve yüksek hızlı web siteleri kesintisiz olarak canlandırılır.</span>
                  </div>
                </div>
              </div>

              <div className="bg-slate-950 p-4 rounded text-[11px] leading-relaxed text-slate-400 font-sans border border-slate-800">
                <strong className="text-indigo-400 block mb-1 font-mono">Mühendis İmzası:</strong>
                {"\"Biz yazılımı hazır bir kalıp olarak kurmuyoruz. Kodların doğrudan satış süreçlerinize hizmet etmesi için mimariyi sizin dinamiklerinize esnetiyoruz.\""}
              </div>

            </div>

          </div>

        </div>
      </section>

      {/* CONSULTATION / TEXT FORM SECTION - Çözüm İstişaresi (No Free Trials, strictly elite sales analysis request) */}
      <section id="istisare" className="py-24 bg-slate-950 text-slate-100 relative border-b border-slate-900">
        <div className="max-w-4xl mx-auto px-4 sm:px-6">
          
          <div className="text-center space-y-4 mb-16">
            <span className="text-xs font-mono font-bold uppercase tracking-widest text-indigo-400 px-3 py-1 bg-indigo-500/10 border border-indigo-500/20 rounded-full">
              KAPALI SİSTEM / KURUMSAL İŞTİŞARE
            </span>
            <h2 className="text-3xl sm:text-4xl font-extrabold tracking-tight text-white font-sans">
              Satış Sürecinizi Beraber Analiz Edelim
            </h2>
            <p className="text-slate-400 font-sans leading-relaxed max-w-2xl mx-auto">
              Süreçlerinize nelerin hız katabileceğini değerlendirmek üzere bir teknik istişare gerçekleştirelim. Karşılıklı analiz sonucu en optimum modüler mimariyi yapılandırıyoruz.
            </p>
          </div>

          <div className="bg-slate-900/40 rounded-2xl border border-slate-800 p-8 shadow-2xl shadow-indigo-500/2">
            
            {formSubmitted ? (
              <div className="text-center py-10 space-y-4">
                <div className="w-16 h-16 rounded-full bg-indigo-500/10 text-indigo-400 border border-indigo-500/20 flex items-center justify-center mx-auto shadow-sm">
                  <CheckCircle2 className="w-8 h-8" />
                </div>
                <h3 className="text-xl font-bold text-white">İletişim Talebi Alındı</h3>
                <p className="text-slate-400 font-sans text-sm max-w-md mx-auto leading-relaxed">
                  Şirketinizin satış dinamiklerini analiz etmek üzere teknik ekibimiz en kısa sürede sizinle iletişime geçecektir.
                </p>
                <button 
                  id="form-success-reset"
                  onClick={() => setFormSubmitted(false)} 
                  className="mt-4 text-xs font-mono text-indigo-400 font-bold hover:underline"
                >
                  Yeni bir analiz formu doldur
                </button>
              </div>
            ) : (
              <form onSubmit={handleContactSubmit} className="space-y-6 font-sans">
                
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
                  
                  {/* Company Name */}
                  <div className="space-y-1.5">
                    <label className="text-xs font-bold text-slate-350 block" htmlFor="company-name">Şirket / Kurum Adı:</label>
                    <input 
                      id="company-name"
                      type="text" 
                      required
                      placeholder="Örn: Apex Teknoloji A.Ş."
                      value={companyName}
                      onChange={(e) => setCompanyName(e.target.value)}
                      className="w-full bg-slate-950 border border-slate-800 rounded-lg px-4 py-2.5 text-sm text-white placeholder-slate-600 focus:outline-hidden focus:border-indigo-500 focus:ring-1 focus:ring-indigo-500 transition-all font-sans"
                    />
                  </div>

                  {/* Operational Size / rep count */}
                  <div className="space-y-1.5 row-start-2 sm:row-start-auto">
                    <label className="text-xs font-bold text-slate-350 block" htmlFor="reps-select">Satış Ekibi Kişi Sayısı:</label>
                    <select 
                      id="reps-select"
                      value={salesRepsCount}
                      onChange={(e) => setSalesRepsCount(e.target.value)}
                      className="w-full bg-slate-950 border border-slate-800 rounded-lg px-4 py-2.5 text-sm text-slate-350 focus:outline-hidden focus:border-indigo-500 transition-all font-sans"
                    >
                      <option value="1-5">1 - 5 Temsilci</option>
                      <option value="6-20">6 - 20 Temsilci</option>
                      <option value="21-50">21 - 50 Temsilci</option>
                      <option value="50+">50+ Temsilci (Özel Altyapı Talebi)</option>
                    </select>
                  </div>

                  {/* Email */}
                  <div className="space-y-1.5">
                    <label className="text-xs font-bold text-slate-350 block" htmlFor="email-input">Kurumsal E-Posta Adresi:</label>
                    <input 
                      id="email-input"
                      type="email" 
                      required
                      placeholder="isim@sirketadi.com"
                      value={contactEmail}
                      onChange={(e) => setContactEmail(e.target.value)}
                      className="w-full bg-slate-950 border border-slate-800 rounded-lg px-4 py-2.5 text-sm text-white placeholder-slate-600 focus:outline-hidden focus:border-indigo-500 focus:ring-1 focus:ring-indigo-500 transition-all font-sans"
                    />
                  </div>

                  {/* Phone */}
                  <div className="space-y-1.5">
                    <label className="text-xs font-bold text-slate-350 block" htmlFor="phone-input">Doğrudan İletişim Numarası:</label>
                    <input 
                      id="phone-input"
                      type="tel" 
                      required
                      placeholder="053X XXX XX XX"
                      value={contactPhone}
                      onChange={(e) => setContactPhone(e.target.value)}
                      className="w-full bg-slate-950 border border-slate-800 rounded-lg px-4 py-2.5 text-sm text-white placeholder-slate-600 focus:outline-hidden focus:border-indigo-500 focus:ring-1 focus:ring-indigo-500 transition-all font-sans"
                    />
                  </div>

                </div>

                {/* Custom requirements comment */}
                <div className="space-y-1.5">
                  <label className="text-xs font-bold text-slate-350 block" htmlFor="comment-textarea">Varsa Eklemek İstediğiniz Özel Modül / Entegrasyon İhtiyaçları:</label>
                  <textarea 
                    id="comment-textarea"
                    rows={4}
                    placeholder="Örn: 'SAP sistemimiz ile çift yönlü müşteri finansal durum mutabakat entegrasyonu talep ediyoruz.'"
                    value={customComment}
                    onChange={(e) => setCustomComment(e.target.value)}
                    className="w-full bg-slate-950 border border-slate-800 rounded-lg px-4 py-2.5 text-sm text-white focus:outline-hidden focus:border-indigo-500 focus:ring-1 focus:ring-indigo-500 transition-all font-sans placeholder:text-slate-600"
                  />
                </div>

                {/* Professional disclaimer matching user constraints */}
                <div className="p-4 bg-slate-950/80 rounded-lg border border-slate-800/80 text-xs text-slate-400 font-sans leading-relaxed">
                  <strong className="text-indigo-400 font-medium block mb-1">Gizlilik Beyanı:</strong>
                  Paylaştığınız tüm performans, süreç ve iletişim verileri gizlilik sözleşmemiz kapsamında kurumsal sır olarak korunur. Herhangi bir hazır kısıtlamalı lisans veya deneme süreci zorlaması olmaksızın, tamamen projelendirilmiş fizibilite aşaması tekliflendirilir.
                </div>

                {formError && (
                  <p className="text-xs text-red-400 font-medium font-sans text-right mb-2">{formError}</p>
                )}

                <div className="text-right">
                  <button 
                    id="submit-analysis-form"
                    type="submit" 
                    className="px-8 py-3.5 bg-indigo-600 hover:bg-indigo-500 text-white font-bold text-sm rounded-lg transition-all shadow-lg shadow-indigo-500/20 hover:shadow-xl flex items-center gap-2 justify-center w-full sm:w-auto ml-auto cursor-pointer"
                  >
                    <span>Analiz Talebini İletin</span>
                    <ArrowRight className="w-4 h-4 text-indigo-200" />
                  </button>
                </div>

              </form>
            )}

          </div>

        </div>
      </section>

      {/* FOOTER */}
      <footer className="bg-slate-950 text-slate-400 py-16 border-t border-slate-900">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          
          <div className="grid grid-cols-1 md:grid-cols-4 gap-12 border-b border-slate-900 pb-12">
            
            {/* Brand details */}
            <div className="space-y-4">
              <div className="flex items-center gap-2 text-white">
                <span className="font-mono font-bold text-lg text-indigo-500">▲</span>
                <span className="text-lg font-extrabold tracking-wider font-mono">ApexCRM</span>
              </div>
              <p className="text-xs font-sans leading-relaxed text-slate-500">
                Satış hunisini optimize eden, geliri zirveye çıkaran ve operasyonu hızlandıran kurumsal çözüm ortağınız.
              </p>
            </div>

            {/* Links Column 1 */}
            <div className="space-y-3 font-sans text-xs">
              <p className="text-white font-bold tracking-wider font-mono">ÇÖZÜMLERİMİZ</p>
              <ul className="space-y-2">
                <li><a href="#neden-apex" className="hover:text-white transition-colors">Satış Odaklı CRM Çekirdeği</a></li>
                <li><a href="#guclendirenler" className="hover:text-white transition-colors">20 Bölüm WhatsApp Kuyruğu</a></li>
                <li><a href="#guclendirenler" className="hover:text-white transition-colors">Telegram Reaksiyon Botu</a></li>
                <li><a href="#guclendirenler" className="hover:text-white transition-colors">Dönüşüm Hızlı Web Altyapısı</a></li>
              </ul>
            </div>

            {/* Links Column 2 */}
            <div className="space-y-3 font-sans text-xs">
              <p className="text-white font-bold tracking-wider font-mono">FELSEFE VE ANALİZ</p>
              <ul className="space-y-2">
                <li><a href="#simulasyon" className="hover:text-white transition-colors">Yatırım Getirisi Simülasyonu</a></li>
                <li><a href="#teknik-mimari" className="hover:text-white transition-colors">Modül Yapılandırma</a></li>
                <li><a href="#teknik-mimari" className="hover:text-white transition-colors">Sıfırdan Entegrasyon Modeli</a></li>
              </ul>
            </div>

            {/* Links Column 3 */}
            <div className="space-y-3 font-sans text-xs">
              <p className="text-white font-bold tracking-wider font-mono">KURUMSAL</p>
              <p className="text-slate-500 leading-relaxed text-xs">
                ApexCRM bir yazılım geliştirici ve kurumsal teknoloji çözüm ortağıdır. Birebir iletişimle çalışırız, hazır paket fiyatlandırmamız veya kısıtlayıcı lisanslarımız yoktur.
              </p>
              <p className="text-slate-400 font-mono text-[11px] block pt-1">
                İletişim E-Posta: <a href="mailto:apexcrmdestek@gmail.com" className="text-indigo-400 font-bold hover:underline">apexcrmdestek@gmail.com</a>
              </p>
            </div>

          </div>

          <div className="pt-8 flex flex-col sm:flex-row justify-between items-center gap-4 text-xs text-slate-650 font-mono">
            <p>© 2026 ApexCRM. Tüm hakları gizlidir. Yazılım Geliştirici ve Kurumsal Çözüm Ortağı.</p>
            <p>Designed with Mathematical Precision</p>
          </div>

        </div>
      </footer>

    </div>
  );
}
