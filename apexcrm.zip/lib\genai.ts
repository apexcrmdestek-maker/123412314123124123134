// Lightweight wrapper for Gemini/GenAI usage with safe mock fallback.
// Importing and calling real Gemini is optional — if `process.env.GEMINI_API_KEY` is
// empty, this module returns deterministic mock responses so the app can run.

export type GenAIResult = {
  text: string;
  mock?: boolean;
  error?: string;
};

export async function generateText(prompt: string): Promise<GenAIResult> {
  const key = process.env.GEMINI_API_KEY || '';
  if (!key) {
    return {
      text: `Mock response for prompt: ${prompt.slice(0, 120)}`,
      mock: true,
    };
  }

  // If a real key exists, attempt a best-effort dynamic import of the official client.
  // If the client or call fails, fall back to a friendly mock response.
  try {
    // Dynamic import to avoid loading the client when not needed.
    // eslint-disable-next-line @typescript-eslint/no-var-requires
    const genai = await import('@google/genai');
    // The official client API surface may change; attempt a generic call if available.
    // If this code path fails, we catch and return a mock instead of throwing.
    if (genai && typeof genai === 'object') {
      // Try common client constructors (best-effort, non-fatal).
      // NOTE: Replace the following with actual integration if you want real Gemini calls.
      // For now, return a placeholder so the app remains stable.
      return {
        text: `Gemini integration present but not fully configured. Prompt: ${prompt.slice(0,120)}`,
        mock: true,
      };
    }
  } catch (e: any) {
    return {
      text: `Gemini client load failed, using mock. Prompt: ${prompt.slice(0,120)}`,
      mock: true,
      error: e?.message ?? String(e),
    };
  }

  return {
    text: `Unhandled path: returning mock for prompt: ${prompt.slice(0,120)}`,
    mock: true,
  };
}
