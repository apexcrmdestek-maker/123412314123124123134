import type {Metadata} from 'next';
import { Inter, JetBrains_Mono } from 'next/font/google';
import './globals.css'; // Global styles

const inter = Inter({
  subsets: ['latin'],
  variable: '--font-sans',
  display: 'swap',
});

const jetbrainsMono = JetBrains_Mono({
  subsets: ['latin'],
  variable: '--font-mono',
  display: 'swap',
});

export const metadata: Metadata = {
  title: 'ApexCRM | Satış Odaklı CRM ve Kurumsal Çözümler',
  description: 'Anlaşmaları kapatmaya ve gelire odaklanan, işletmenizin satış hunisini yöneten modern CRM platformu ve kurumsal çözümler.',
};

export default function RootLayout({children}: {children: React.ReactNode}) {
  return (
    <html lang="tr" className={`${inter.variable} ${jetbrainsMono.variable}`}>
      <body className="font-sans antialiased text-slate-900 bg-slate-50/50" suppressHydrationWarning>
        {children}
      </body>
    </html>
  );
}
